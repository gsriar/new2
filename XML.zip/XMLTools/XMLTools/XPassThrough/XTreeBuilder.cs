﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using SharedHelper;

namespace XPassThrough
{
    public class XTreeBuilder
    {
        public readonly static XTreeBuilder Instance = new XTreeBuilder();
        private XMeta xMeta = null;

        public XMeta BuidXTree(XDocument xml)
        {
            xMeta = new XMeta(xml) { NodeCollection = new List<Node>() };
            BuidRecursiveNode2(xml.Root);
            return xMeta;
        }

        
        private void BuidRecursiveNode2(XElement root)
        {
            bool hasAttributes = false;
            bool hasInnerXelements = false;
            bool hasText = false;
            Node rootXTreeNode = null;

            if (root != null)
            {
                QualifiedName rootXTreeNodeQualifiedName = new QualifiedName(root.Name);

                rootXTreeNode = xMeta.NodeCollection.FirstOrDefault(n => n.QualifiedName.ShallowSame(rootXTreeNodeQualifiedName));

                if (rootXTreeNode == null)
                {
                    rootXTreeNode = new Node() { QualifiedName = rootXTreeNodeQualifiedName, AttributeCollection = new List<Attribute>(), ChidCollection = new List<Chid>()
                        //, InnerTextCollection = new ValueCollection<string>() 
                    };
                    xMeta.NodeCollection.Add(rootXTreeNode);
                }

                if (root.Parent != null)
                {
                    int rootParrallelOccurance = root.Parent.Nodes().Where(n => n is XElement && (n as XElement).Name == root.Name).Count();

                    if (rootXTreeNode.MaxParallelOccurance < rootParrallelOccurance)
                    {
                        rootXTreeNode.MaxParallelOccurance = rootParrallelOccurance;
                    }
                }
                
                foreach (XAttribute rootAttribute in root.Attributes())
                {
                    hasAttributes = true;
                    var attr = rootXTreeNode.AttributeCollection.FirstOrDefault(n => n.QualifiedName.ShallowSame(rootAttribute.Name));
                    if (attr == null)
                    {
                        attr = new Attribute() { QualifiedName = new QualifiedName(rootAttribute.Name), AttributeValueCollection = new ValueCollection<string>() };
                        rootXTreeNode.AttributeCollection.Add(attr);
                    }
                    var preExistAttributeValue = attr.AttributeValueCollection.FirstOrDefault(v => v == rootAttribute.Value.TrimSpecial());
                    if (preExistAttributeValue == null)
                    {
                        attr.AttributeValueCollection.Add(rootAttribute.Value.TrimSpecial());
                    }
                }

                foreach (XNode rootChild in root.Nodes().Where(x=> x is XElement))
                {
                    hasInnerXelements = true;
                    var xe = rootChild as XElement;

                    if (xe.Attributes().Count() == 0 && xe.Nodes().Where(x => x is XElement).Count() == 0)
                    {
                        var attr = rootXTreeNode.AttributeCollection.FirstOrDefault(n => n.QualifiedName.ShallowSame(xe.Name));
                        if (attr == null)
                        {
                            attr = new Attribute() { QualifiedName = new QualifiedName(xe.Name), AttributeValueCollection = new ValueCollection<string>() };
                            attr.AttributeType = AttributeType.Element;
                            rootXTreeNode.AttributeCollection.Add(attr);
                        }

                        var preExistAttributeValue = attr.AttributeValueCollection.FirstOrDefault(v => v == xe.Value.TrimSpecial());
                        if (preExistAttributeValue == null)
                        {
                            attr.AttributeValueCollection.Add(xe.Value.TrimSpecial());
                        }
                    }
                    else
                    {
                        BuidRecursiveNode2(xe);
                    }
                }


                if (hasAttributes && !hasInnerXelements && root.Nodes().Where(n => n is XText).Count() > 0)
                {
                    var attr = new Attribute() { AttributeType=XPassThrough.AttributeType.Text, QualifiedName = new QualifiedName("NodeText"), AttributeValueCollection = new ValueCollection<string>() };
                    rootXTreeNode.AttributeCollection.Add(attr);
                    if (attr.AttributeValueCollection.IndexOf(root.Value.TrimSpecial()) == -1)
                    {
                        attr.AttributeValueCollection.Add(root.Value.TrimSpecial());
                    }
                }

                foreach (XNode rootChildNode in root.Nodes())
                {
                    if (rootChildNode is XElement)
                    {
                        XElement rootElementChild = rootChildNode as XElement;

                        var cn = rootXTreeNode.ChidCollection.FindAll(n =>
                        {
                            return n.QualifiedName.ShallowSame(rootElementChild.Name);
                        });

                        if (cn.Count == 0)
                        {
                            var equiXNode = xMeta.NodeCollection.FirstOrDefault(n => n.QualifiedName.ShallowSame(rootElementChild.Name));
                            if (equiXNode != null)
                            {
                                var s = new Chid() { QualifiedName = equiXNode.QualifiedName };
                                rootXTreeNode.ChidCollection.Add(s);
                            } 
                        }
                    }

                    if (rootChildNode is XText)
                    {
                    }

                }

            }

        }

    }
}
