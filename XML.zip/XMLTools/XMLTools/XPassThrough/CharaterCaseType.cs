﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XPassThrough
{
    public enum CharaterCaseType
    {
        None,
        Pascal,
        Camel,
        Upper,
        Lower
    }
}
