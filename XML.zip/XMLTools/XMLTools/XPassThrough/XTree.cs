﻿using System;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Xml.Linq;

namespace XPassThrough
{
    public enum AttributeType
    {
        Attribute,
        Element,
        Text
    }

    public abstract class XBase
    {
        [XmlElement(ElementName = "QualifiedName")]
        public QualifiedName QualifiedName { get; set; }
    }

    [XmlRoot(ElementName = "XMeta")]
    public class XMeta
    {
        [XmlElement(ElementName = "Node")]
        public List<Node> NodeCollection { get; set; }

        public XMeta(XDocument xml)
        {
            xDocument = xml;
        }

        public XMeta()
        {
            xDocument = null;
        }

        private XDocument xDocument;

        public XDocument GetXDocument()
        {
            return xDocument;
        }
    }

    [XmlRoot(ElementName = "Value")]
    public class ValueCollection<T> : List<T>
    { }

    [XmlRoot(ElementName = "Node")]
    public class Node : XBase
    {
        [XmlElement(ElementName = "Attribute")]
        public List<Attribute> AttributeCollection { get; set; }

        [XmlElement(ElementName = "Chid")]
        public List<Chid> ChidCollection { get; set; }

        [XmlAttribute(AttributeName = "MaxParallelOccurance")]
        public int MaxParallelOccurance { get; set; }

        //[XmlElement(ElementName = "InnerTextValue")]
        //public ValueCollection<string> InnerTextCollection { get; set; }
    }

    [XmlRoot(ElementName = "Attribute")]
    public class Attribute : XBase
    {
        [XmlAttribute(AttributeName = "AttributeType")]
        public AttributeType AttributeType { get; set; }

        [XmlElement(ElementName = "AttributeValue")]
        public ValueCollection<string> AttributeValueCollection { get; set; }
    }

    [XmlRoot(ElementName = "Chid")]
    public class Chid : XBase
    {
        [XmlAttribute(AttributeName = "Count")]
        public int Count { get; set; }
    }

    [XmlRoot(ElementName = "QualifiedName")]
    public class QualifiedName
    {
        public QualifiedName()
        {
        }

        public QualifiedName(XName xname)
        {
            Name = xname.LocalName;
            NameSpace = xname.NamespaceName;
            NameSpaceName = xname.NamespaceName;
        }

        [XmlAttribute(AttributeName = "Name")]
        public string Name { get; set; }

        [XmlAttribute(AttributeName = "NameSpace")]
        public string NameSpace { get; set; }

        [XmlAttribute(AttributeName = "NameSpaceName")]
        public string NameSpaceName { get; set; }

        public bool ShallowSame(QualifiedName obj)
        {
            if (obj != null)
                return (this.Name == obj.Name && this.NameSpace == obj.NameSpace);
            else
                return false;
        }

        public bool ShallowSame(XName obj)
        {
            if (obj != null)
                return (this.Name == obj.LocalName && this.NameSpace == obj.NamespaceName);
            else
                return false;
        }

        [XmlAttribute(AttributeName = "CustomName")]
        public string CustomName { get; set; }

        internal void CustomizeName(CharacterCasingOption option, bool keepNameSpace = false)
        {
            if (keepNameSpace && !string.IsNullOrWhiteSpace(this.NameSpace))
            {
                string url = "http://" + this.NameSpace;
                System.Uri uri = new System.Uri(url);

                this.CustomName = (uri.Segments[uri.Segments.Length - 1]).ToUpper() + "_" + this.Name.ApplySQLNameConvention(option);
            }
            else
            {
                if (String.Equals(this.Name, "id", StringComparison.OrdinalIgnoreCase))
                {
                }
                this.CustomName = this.Name.ApplySQLNameConvention(option);
                
            }
        }
    }
}
