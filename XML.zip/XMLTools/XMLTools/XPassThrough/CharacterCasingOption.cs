﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XPassThrough
{
    public enum KeywordReplace
    {
        None,
        Both,
        SQL,
        CSharp
    }

    public class CharacterCasingOption
    {
        public char SpecialCharReplacement = ' ';

        public CharaterCaseType CharCaseType { get; set; }

        public bool AppendNameSpace { get; set; }

        public SpecialCase SpecialCase = new SpecialCase() { MinLen = 1, MaxLen = 3 };

        public CharaterCaseType SpecialCharCaseType = CharaterCaseType.Upper;

        public KeywordReplace KeywordReplace { get; set; }
    }

    public class SpecialCase
    {
        public int MinLen { get; set; }
        public int MaxLen { get; set; }

        public bool Qualify(string text)
        {
            if (string.IsNullOrEmpty(text))
                return false;
            else
                return text.Length >= MinLen && text.Length <= MaxLen;
        }
    }
}
