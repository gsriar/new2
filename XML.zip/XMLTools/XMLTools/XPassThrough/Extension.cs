﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharedHelper;

namespace XPassThrough
{
    public static class Extension
    {
        public static List<string> SQLKeywords = new List<string>(new string[] 
        { 
          "ADD", "EXTERNAL", "PROCEDURE", "ALL", "FETCH", "PUBLIC", "ALTER", "FILE", "RAISERROR", "AND", "FILLFACTOR", "READ", "ANY", "FOR", "READTEXT", "AS",
          "FOREIGN", "RECONFIGURE", "ASC", "FREETEXT", "REFERENCES", "AUTHORIZATION", "FREETEXTTABLE", "REPLICATION", "BACKUP", "FROM", "RESTORE", "BEGIN", 
          "FULL", "RESTRICT", "BETWEEN", "FUNCTION", "RETURN", "BREAK", "GOTO", "REVERT", "BROWSE", "GRANT", "REVOKE", "BULK", "GROUP", "RIGHT", "BY", "HAVING",
          "ROLLBACK", "CASCADE", "HOLDLOCK", "ROWCOUNT", "CASE", "IDENTITY", "ROWGUIDCOL", "CHECK", "IDENTITY_INSERT", "RULE", "CHECKPOINT", "IDENTITYCOL", 
          "SAVE", "CLOSE", "IF", "SCHEMA", "CLUSTERED", "IN", "SECURITYAUDIT", "COALESCE", "INDEX", "SELECT", "COLLATE", "INNER", "SEMANTICKEYPHRASETABLE", 
          "COLUMN", "INSERT", "SEMANTICSIMILARITYDETAILSTABLE", "COMMIT", "INTERSECT", "SEMANTICSIMILARITYTABLE", "COMPUTE", "INTO", "SESSION_USER", 
          "CONSTRAINT", "IS", "SET", "CONTAINS", "JOIN", "SETUSER", "CONTAINSTABLE", "KEY", "SHUTDOWN", "CONTINUE", "KILL", "SOME", "CONVERT", "LEFT", 
          "STATISTICS", "CREATE", "LIKE", "SYSTEM_USER", "CROSS", "LINENO", "TABLE", "CURRENT", "LOAD", "TABLESAMPLE", "CURRENT_DATE", "MERGE", "TEXTSIZE", 
          "CURRENT_TIME", "NATIONAL", "THEN", "CURRENT_TIMESTAMP", "NOCHECK", "TO", "CURRENT_USER", "NONCLUSTERED", "TOP", "CURSOR", "NOT", "TRAN", 
          "DATABASE", "NULL", "TRANSACTION", "DBCC", "NULLIF", "TRIGGER", "DEALLOCATE", "OF", "TRUNCATE", "DECLARE", "OFF", "TRY_CONVERT", "DEFAULT", 
          "OFFSETS", "TSEQUAL", "DELETE", "ON", "UNION", "DENY", "OPEN", "UNIQUE", "DESC", "OPENDATASOURCE", "UNPIVOT", "DISK", "OPENQUERY", "UPDATE", 
          "DISTINCT", "OPENROWSET", "UPDATETEXT", "DISTRIBUTED", "OPENXML", "USE", "DOUBLE", "OPTION", "USER", "DROP", "OR", "VALUES", "DUMP", "ORDER", 
          "VARYING", "ELSE", "OUTER", "VIEW", "END", "OVER", "WAITFOR", "ERRLVL", "PERCENT", "WHEN", "ESCAPE", "PIVOT", "WHERE", "EXCEPT", "PLAN",
          "WHILE", "EXEC", "PRECISION", "WITH", "EXECUTE", "PRIMARY", "WITHIN GROUP", "EXISTS", "PRINT", "WRITETEXT", "EXIT", "PROC"
        });


        public static List<string> CSKeywords = new List<string>(new string[] 
        { 
            "abstract", "as", "base", "bool", "break", "byte", "case", "catch", "char", "checked", "class", "const", "continue", "decimal", 
            "default", "delegate", "do", "double", "else", "enum", "event", "explicit", "extern", "false", "finally", "fixed", "float", 
            "for", "foreach", "goto", "if", "implicit", "in", "int", "interface", "internal", "is", "lock", "long", "namespace", "new", 
            "null", "object", "operator", "out", "override", "params", "private", "protected", "public", "readonly", "ref", 
            "return", "sbyte", "sealed", "short", "sizeof", "stackalloc", "static", "string", "struct", "switch", "this", "throw", 
            "true", "try", "typeof", "uint", "ulong", "unchecked", "unsafe", "ushort", "using", "virtual", "void", "volatile", "while" 
        });


        public static void FormatQualifiedName(this XMeta xMeta, CharacterCasingOption Option)
        {
            List<Node> special = new List<Node>();

            foreach (var node in xMeta.NodeCollection)
            {
                //treat special the multiple nodes with same name, so that formatted name can be prefixed
                var nodes = xMeta.NodeCollection.FindAll(n => n.QualifiedName.Name.Equals(node.QualifiedName.Name, StringComparison.OrdinalIgnoreCase));
                if (nodes.Count > 1)
                {
                    foreach (var n1 in nodes)
                    {
                        if (!special.Contains(n1))
                        {
                            special.Add(n1);
                        }
                    }
                }
            }

            foreach (var node in xMeta.NodeCollection)
            {
                if (special.Contains(node))
                {
                    node.QualifiedName.CustomizeName(Option, true);
                }
                else
                {
                    node.QualifiedName.CustomizeName(Option);
                }

                foreach (var child in node.AttributeCollection)
                {
                    child.QualifiedName.CustomizeName(Option);
                }
            }
        }
        
        public static void CleanXtree(this XMeta xMeta)
        {
            //var noAttribNodes = xMeta.NodeCollection.FindAll(o => o.AttributeCollection.Count == 0 && o.ChidCollection.Count == 0 && o.MaxParallelOccurance == 1);

           
            //foreach (var node in noAttribNodes)
            //{
            //    foreach (var treeNode in xMeta.NodeCollection)
            //    {
            //        var sibling = treeNode.ChidCollection.FindAll(sb => sb.QualifiedName.Name == node.QualifiedName.Name && sb.QualifiedName.NameSpace == node.QualifiedName.NameSpace);

            //        foreach (var sbl in sibling)
            //        {
            //            treeNode.ChidCollection.Remove(sbl);
            //            Attribute a = new Attribute()
            //            {
            //                QualifiedName = sbl.QualifiedName,
            //                AttributeValueCollection = node.InnerTextCollection,
            //                AttributeType = AttributeType.Element
            //            };

            //            treeNode.AttributeCollection.Add(a);
            //        }
            //    }
            //}

            //noAttribNodes.ForEach(r => xMeta.NodeCollection.Remove(r));
        }

        public static void CleanAndApplyQualifiedName(this XMeta xMeta, CharacterCasingOption Option)
        {
            xMeta.CleanXtree();
            xMeta.FormatQualifiedName(Option);
        }

        public static string ApplySQLNameConvention(this string name, CharacterCasingOption option)
        {
            if (name != null)
            {
                if (!string.IsNullOrWhiteSpace(name))
                {
                    var caseType = option.CharCaseType;

                    if (option.SpecialCase != null && option.SpecialCase.Qualify(name))
                        caseType = option.SpecialCharCaseType;

                    switch (caseType)
                    {
                        case CharaterCaseType.None:
                            name = name.ReplaceSQLSpecialCharactersWith(' ').ToContinuousString();
                            break;

                        case CharaterCaseType.Pascal:
                            name = name.ReplaceSQLSpecialCharactersWith(' ').ToProperCase().ToPascalCase();
                            break;

                        case CharaterCaseType.Camel:
                            name = name.ReplaceSQLSpecialCharactersWith(' ').ToProperCase().ToCamelCase();
                            break;

                        case CharaterCaseType.Lower:
                            name = name.ReplaceSQLSpecialCharactersWith(' ').ToProperCase().ToContinuousString().ToLower();
                            break;

                        case CharaterCaseType.Upper:
                            name = name.ReplaceSQLSpecialCharactersWith(' ').ToContinuousString().ToUpper();
                            break;
                    }

                }

                switch (option.KeywordReplace)
                {
                    case KeywordReplace.Both:
                        if (CSKeywords.FirstOrDefault(f => f.Equals(name, StringComparison.OrdinalIgnoreCase)) != null
                            || SQLKeywords.FirstOrDefault(f => f.Equals(name, StringComparison.OrdinalIgnoreCase)) != null)
                            name = "_" + name;
                        break;
                    case KeywordReplace.CSharp:
                        if (CSKeywords.FirstOrDefault(f => f.Equals(name, StringComparison.OrdinalIgnoreCase)) != null)
                            name = "_" + name;
                        break;
                    case KeywordReplace.SQL:
                        if (SQLKeywords.FirstOrDefault(f => f.Equals(name, StringComparison.OrdinalIgnoreCase)) != null)
                            name = "_" + name;
                        break;
                }
            }
            return name;
        }
    }
}
