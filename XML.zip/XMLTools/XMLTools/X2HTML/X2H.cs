﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using XPassThrough;

namespace X2HTML
{
    public class X2H
    {

        private NameValue box = new NameValue() { Name = "class", Value = "box" };
        private NameValue zebra = new NameValue() { Name = "class", Value = "zebra" };
        private NameValue textleft = new NameValue() { Name = "class", Value = "textleft" };
        private NameValue x2h = new NameValue() { Name = "id", Value = "x2h" };
        private NameValue nodeTD = new NameValue() { Name = "class", Value = "nodeTD" };


        private XMeta xMeta = null;
        private XDocument xmldoc;
        private HtmlWriter hw = null;
        int mAXCOL = 0;

        string resourcepath = null;

        private void parseXMeta()
        {
            xMeta = XTreeBuilder.Instance.BuidXTree(xmldoc);
            CharacterCasingOption characterCasingOption = new CharacterCasingOption() { CharCaseType = CharaterCaseType.None, SpecialCharCaseType = CharaterCaseType.None };
            xMeta.FormatQualifiedName(characterCasingOption);

            foreach (var n in xMeta.NodeCollection)
            {
                if (n.AttributeCollection.Count > mAXCOL)
                    mAXCOL = n.AttributeCollection.Count;
            }
        }

        public X2H(string resourcepath, XDocument xmldoc, TextWriter textwriter)
        {
            this.resourcepath = resourcepath;
            this.xmldoc = xmldoc;
            parseXMeta();
            this.hw = new HtmlWriter(textwriter);
        }



        public void HTMLParse()
        {
            var xfirstNode = xmldoc.Nodes().Where(f => f is XElement).First() as XElement;

            var fn = xMeta.NodeCollection.First(f => f.QualifiedName.ShallowSame((xfirstNode as XElement).Name));
            XElement[] root = { xmldoc.Root };
            hw.BeginTag(html.Div, x2h);
            hw.WriteLine();
            hw.WriteText(string.Format("<style>{0}</style>", File.ReadAllText(Path.Combine(this.resourcepath, @"xml.css"))));

            hw.WriteLine();
            hw.WriteText(@"<script type='text/javascript'>
function htoggle(ELEMENT, SENDER) {
		if(ELEMENT.offsetWidth > 0 || ELEMENT.offsetHeight > 0)
		{
			ELEMENT.style.display = 'none';
SENDER.innerHTML='+';
		}
		else
		{
			ELEMENT.style.display = 'block';
SENDER.innerHTML='-';
		}
}
</script>");

            hw.WriteLine();
            HTMLParse(fn, root);
            hw.EndTag(html.Div);
        }

        int indent = 0;
        int id = 0;
        private void HTMLParse(Node node, IEnumerable<XElement> xml)
        {
            indent++;
            if (xml.Count() > 0)
            {
                string tid = "_" + ++id;
                this.hw.WriteTag(html.H3, "<button class='toggler' onclick='javascript:htoggle(" + tid + ", this)'>-</button><span class='angle'>&lt</span>" + node.QualifiedName.CustomName + "<span class='angle'>&gt</span>", textleft);

                hw.WriteLine();
                hw.BeginTag(html.Div, box);
                hw.WriteLine();
                hw.BeginTag(html.Table, zebra, GetID(id));
                hw.WriteLine();
                if (node.AttributeCollection.Count > 0)
                {
                    hw.BeginTag(html.TR);
                    hw.WriteTag(html.TH, "&nbsp;");
                    foreach (var a in node.AttributeCollection)
                    {
                        hw.WriteTag(html.TH, a.QualifiedName.CustomName, null);
                    }
                    hw.EndTag(html.TR);
                }


                hw.WriteLine();
                ProcessChild(node, xml);
                hw.EndTag(html.Table);
                hw.WriteLine();
                hw.EndTag(html.Div);
                hw.WriteLine();
            }

            indent--;
        }
        public void ProcessChild(Node node, IEnumerable<XElement> xml)
        {
            foreach (var xmlChild in xml)
            {
                PrepareDataRow(xmlChild, node);

                foreach (var child in node.ChidCollection)
                {
                    var childNode = this.xMeta.NodeCollection.FirstOrDefault(f => child.QualifiedName.ShallowSame(f.QualifiedName));

                    IEnumerable<XNode> nodes = xmlChild.Nodes().Where(x1 => x1 is XElement).Where(x2 => childNode.QualifiedName.ShallowSame((x2 as XElement).Name));
                    if (nodes.Count() > 0)
                    {
                        hw.BeginTag(html.TR);
                        hw.WriteTag(html.TD, node.QualifiedName.CustomName, nodeTD);
                        if (node.AttributeCollection.Count > 0)
                            hw.BeginTag(html.TD, new NameValue() { Name = "colspan", Value = node.AttributeCollection.Count.ToString() });
                        else
                            hw.BeginTag(html.TD);

                        HTMLParse(childNode, EnumrateXElement(nodes));

                        hw.EndTag(html.TD);
                        hw.EndTag(html.TR);
                    }
                }
            }
        }
        private NameValue GetColSpan(Node node)
        {
            if (node.AttributeCollection.Count > 0)
                return new NameValue() { Name = "colspan", Value = node.AttributeCollection.Count.ToString() };
            else
                return null;
        }


        public void PrepareDataRow(XElement e, Node node)
        {
            List<XAttribute> xattributes = e.Attributes().ToList();

            IEnumerable<XNode> xelelements = e.Nodes().Where(n => n is XElement);
            if (node.AttributeCollection.Count > 0)
            {
                this.hw.BeginTag(html.TR);
                hw.WriteTag(html.TD, node.QualifiedName.CustomName, nodeTD);
                foreach (var metaAttrib in node.AttributeCollection)
                {
                    this.hw.BeginTag(html.TD);
                    switch (metaAttrib.AttributeType)
                    {
                        case AttributeType.Attribute:

                            var attribute = xattributes.FirstOrDefault(f => metaAttrib.QualifiedName.ShallowSame(f.Name));

                            if (attribute != null && !string.IsNullOrEmpty(attribute.Value))
                                this.hw.WriteText(attribute.Value);
                            break;
                        case AttributeType.Element:

                            XElement xe = xelelements.FirstOrDefault(el => metaAttrib.QualifiedName.ShallowSame((el as XElement).Name)) as XElement;

                            if (xe != null && !string.IsNullOrEmpty(xe.Value))
                                this.hw.WriteText(xe.Value);
                            break;
                        case AttributeType.Text:
                            this.hw.WriteText(e.Value);
                            break;
                    }
                    this.hw.EndTag(html.TD);
                }


                this.hw.EndTag(html.TR);
            }
            hw.WriteLine();

        }

        public NameValue GetIndent(int indent)
        {
            return new NameValue() { Name = "style", Value = "margin-left:" + 0 + "px;" };
        }


        public NameValue GetID(int id)
        {
            return new NameValue() { Name = "id", Value = "_" + id };
        }



        private IEnumerable<XElement> EnumrateXElement(IEnumerable<XNode> nodes)
        {

            foreach (XElement xe in nodes)
                yield return xe;

        }


    }
}
