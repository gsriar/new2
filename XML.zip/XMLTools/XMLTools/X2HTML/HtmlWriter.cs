﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace X2HTML
{
    public class NameValue
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }

    public class html
    {
        public const string Div = "DIV";
        public const string Table = "Table";
        public const string TR = "TR";
        public const string TD = "TD";
        public const string TH = "TH";
        public const string H1 = "H1";
        public const string H3 = "H3";
        public const string Class = "Class";
    }

    class HtmlWriter
    {
        TextWriter Writer;
        public HtmlWriter(TextWriter Writer)
        {
            this.Writer = Writer;
        }

        public void WriteTag(string tag, string text,params NameValue[] nameValues)
        {

            BeginTag(tag, nameValues);
            WriteText(text);
            EndTag(tag);

        }

        public void BeginTag(string tag)
        {
            this.Writer.Write("<{0}>", tag);
        }

        public void WriteLine()
        {
            this.Writer.WriteLine();
        }

        public void WriteComment( string comment)
        {
            this.Writer.Write("<!--{0}-->", comment);
        }

        public void BeginTag(string tag, params NameValue[] nameValues)
        {
            this.Writer.Write("<{0}", tag);
            WriteAttribute(nameValues);
            EndAngleBracket();
        }

        public void WriteAttribute(params NameValue[] nameValues)
        {
            if (nameValues == null)
                return;
            foreach (var nv in nameValues)
            {
                this.Writer.Write(" {0}=\"{1}\"", nv.Name, nv.Value);
            }
        }

        private void EndAngleBracket()
        {
            this.Writer.Write(">");
        }

        public void WriteText(string text)
        {
            this.Writer.Write(text);
        }


        public void EndTag(string tag)
        {
            this.Writer.Write("</{0}>", tag);
        }

    }
}
