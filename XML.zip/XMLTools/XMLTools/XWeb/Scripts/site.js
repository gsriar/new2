﻿var files;
var xmlattachmentid = 'XmlAttachment';
var downloadFileName = "test.txt";



$.fn.selectText = function () {
    var doc = document;
    var element = this[0];
    if (doc.body.createTextRange) {
        var range = document.body.createTextRange();
        range.moveToElementText(element);
        range.select();
    } else if (window.getSelection) {
        var selection = window.getSelection();
        var range = document.createRange();
        range.selectNodeContents(element);
        selection.removeAllRanges();
        selection.addRange(range);
    }
};


init = function () {
    $("#copytoclipboard").text('Copy to clipboard..')
    $('#XML').focus();
    $('input[name="OutputType"]').attr('checked', false);
    var xmlattachment = $('#' + xmlattachmentid);
    $(XmlAttachment).val('');
    if ($(XmlAttachment).attr('type') == "file")
        files = null;
}

$(document).ready(function () {

    $('#mt').click(function () {
        $('#toollist').toggle();

        ($("#mt").text() === "+ Show More Converters") ? $("#mt").text("- Hide") : $("#mt").text("+ Show More Converters");
    });

    init();

    $("#btnLoadSampleXml").click(function () {
        $.ajax({
            type: "get",
            url: "/Sample/Xml",
            dataType: "text",
            success: function (data) {
                /* handle data here */
                $("#XML").val(data);
            },
            error: function (xhr, status) {
                alert("Error loading sample file");
            }
        });
    });

    // Grab the files and set them to our variable
    prepareUpload = function (event) {
        files = event.target.files;
    }
    // Add events
    $('input[type=file]').on('change', prepareUpload);


    getFormData = function () {
        var data = new FormData();
        var nameValues = $("#mainWrapper").find("select, textarea, input").serializeArray();
        $.each(nameValues, function (index, value) {
            data.append(value.name, value.value);
        });

        if (typeof (files) != 'undefined' && files != null) {
            
            $.each(files, function (key, value) {
                if (files[key].type == "text/xml" || files[key].type == "application/xml") {
                    data.append(xmlattachmentid, value);
                }
            });
        }
        return data;
    }

    postRequest = function (event, url, lang) {
        ajaxPost(url, lang, getFormData());
    }

    ajaxPost = function (url, lang, jsondata) {
        $('#loader').show();
        $.ajax({
            url: url,
            type: 'POST',
            data: jsondata,
            cache: false,
            processData: false, // Don't process the files
            contentType: false, // Set content type to false as jQuery will tell the server its a query string request
            success: function (result, textStatus, jqXHR) {
                $('#loader').hide();
                $('#html').html('');
                $('#resultDiv #cR').text('');
                $('#resultwrap1').hide();

                if (result.match("^SERVER ERROR:")) {
                    $('#errortext').text(result);
                    $('#errorbox').show();
                 
                    return;
                }

                try {
                    ext = lang.split("-").pop();
                    if (ext == "csharp")
                        ext = "cs";
                    downloadFileName = 'xmlconvert.' + ext;
                } catch (err) { }

                $('#resultDiv').show();
                copyfordownload(result);



                if (lang.indexOf("html") > 0) {
                    $('pre.result').hide();
                    $('#resultDiv #cR').hide();
                    $('#html').html(result);
                }
                else {
                    $('pre.result').show();
                    $('#resultDiv #cR').show();
                    $('#resultDiv #cR').attr("class", lang);
                    $('#resultDiv #cR').text(result);
                }
                $('#resultwrap1').show();
                resultAreaRest();
                $('pre code').each(function (i, block) {
                    Prism.highlightElement(block);
                    $('.prism-show-language').hide();
                });
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $('#loader').hide();
                alert('ERROR: ' + textStatus);
                $('#resultDiv #cR').text();
            }
        });
    }

    saveTextAsFile = function (filename) {
        var textFileAsBlob = new Blob([$('#resulttextarea').val()], { type: 'text/plain' });
        var downloadLink = document.createElement("a");
        downloadLink.download = filename;
        if (window.webkitURL != null) {
            // Chrome allows the link to be clicked
            // without actually adding it to the DOM.
            downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
        }
        else {
            // Firefox requires the link to be added to the DOM
            // before it can be clicked.
            downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
            downloadLink.onclick = destroyClickedElement;
            downloadLink.style.display = "none";
            document.body.appendChild(downloadLink);
        }
        downloadLink.click();
    }

    destroyClickedElement = function () {
        $(this).remove();
    }

    copyfordownload = function (text) {
        $('#resulttextarea').remove();
        var textareaElement = $('<textarea></textarea>');
        $(textareaElement).attr({ "style": "display: none;", "value": '', "id": 'resulttextarea' });
        $('#resultDiv').remove('input#resultText');
        $('#resultDiv').append(textareaElement);
        $('#resulttextarea').val(text)
    }

    $('#' + xmlattachmentid).change(function () {
        var filename = $(this).val();
        if (!(/\.xml/.test(filename) || /\.xsd/.test(filename) || /\.xsl/.test(filename))) {
            $(this).val('')
            alert('Please select a xml file');
        }
    });

    clear = function (obj) {
        var targetid = $(obj).attr('target');
        var targetElement = $('#' + targetid);
        $(targetElement).val('');
        if ($(targetElement).attr('type') == "file") {
            $(targetElement).removeAttr('value');
            files = null;
        }

        $(targetElement).focus();
        return false;
    }

    $('.clear').click(function () { return clear(this); });

    $('.radio_option').click(function (event) {
        postRequest(event, $(this).attr("targetURL"), $(this).attr("targetlang"));
    });

    $('.actionbtn').click(function (event) { postRequest(event, $(this).attr("targetURL"), $(this).attr("targetlang")) });
    $('#download').click(function () { saveTextAsFile(downloadFileName); });

});



$(document).ready(function () {
    $(document).keyup(function (e) {
        if (e.keyCode == 27) { // escape key maps to keycode `27`
            if ($('#overlay').hasClass("overlay"))
                overlaySwitch();
        }
    });


    resultAreaRest = function () {
        t = $('#resultsection').offset().top;
        wh = $(window).height();

        if (wh > t) {
            y = 20;
            //alert(wh + "#" + t + "#" + (wh - (t + y)));
            $('pre.result').css('max-height', (wh - (t + y)) + "px");
        }
        else {
            $('pre.result').css('max-height', "500px");
        }
    }

    resultAreaRest();


    overlaySwitch = function () {
        jQuery("#overlay").hide()
        if ($('#overlay').hasClass("overlay")) {
            $('#overlay').removeClass("overlay");
            jQuery("#overlay").detach().appendTo('#resultwrap1');

            jQuery("#overlay .overlaycontent").css('width', '');
            jQuery("#overlay .overlaycontent").css('height', '');
            $('#fullscreen').text("full screen mode..");
            jQuery("#overlay").show()
            resultAreaRest();
        }
        else {
            $('#overlay').addClass("overlay");
            jQuery("#overlay").detach().appendTo('body')

            wH = $(window).height();
            wW = $(window).width();

            jQuery("#overlay .overlaycontent").css('width', (wW - 20) + "px");
            jQuery("#overlay .overlaycontent").css('height', (wH - 20) + "px");
            $('#fullscreen').text("exit full screen..");
            $('pre.result').css('max-height', '');
        }
        jQuery("#overlay").show()
    }

});