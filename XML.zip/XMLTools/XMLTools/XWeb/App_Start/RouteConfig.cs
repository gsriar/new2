﻿using System.Web.Mvc;
using System.Web.Routing;
using XWeb.Code;
using XWeb.Models;

namespace XWeb
{
    public static class RouteControllerAction
    {
        public static readonly ControllerAction XmlConvert = new ControllerAction("xml", "Convert");
    }

    public static class Rt
    {
        public static readonly RouteInfo CSV = new RouteInfo("csv", "csv", RouteControllerAction.XmlConvert);
        public static readonly RouteInfo Xml = new RouteInfo("Xml", "Xml", RouteControllerAction.XmlConvert);
        public static readonly RouteInfo Xml2Sql = new RouteInfo("xml-to-sql", "xml-converter/xml-to-sql-script", RouteControllerAction.XmlConvert);
        public static readonly RouteInfo Xml2Json = new RouteInfo("xml-to-json", "xml-converter/xml-to-json", RouteControllerAction.XmlConvert);
        public static readonly RouteInfo Xml2Csharp = new RouteInfo("xml-to-csharp", "xml-converter/xml-to-csharp", RouteControllerAction.XmlConvert);
        public static readonly RouteInfo Xml2Html = new RouteInfo("xml-to-html", "xml-converter/xml-to-html", RouteControllerAction.XmlConvert);
        public static readonly RouteInfo Default = new RouteInfo("Default", "{controller}/{action}", RouteControllerAction.XmlConvert);
    }

    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
            name: Rt.CSV.Name,
            url: Rt.CSV.Url,
            defaults: new { controller = Rt.CSV.Default.Controller, action = Rt.CSV.Default.Action, TargetConversionType = ConversionType.XML2Csharp }
            );

            routes.MapRoute(
            name: Rt.Xml.Name,
            url: Rt.Xml.Name,
            defaults: new { controller = Rt.Xml.Default.Controller, action = Rt.Xml.Default.Action, TargetConversionType = ConversionType.XML2Csharp }
            );

            routes.MapRoute(
            name: Rt.Xml2Sql.Name,
            url: Rt.Xml2Sql.Url,
            defaults: new { controller = Rt.Xml2Sql.Default.Controller, action = Rt.Xml2Sql.Default.Action, TargetConversionType = ConversionType.XML2SQL }
            );

            routes.MapRoute(
            name: Rt.Xml2Json.Name,
            url: Rt.Xml2Json.Url,
            defaults: new { controller = Rt.Xml2Json.Default.Controller, action = Rt.Xml2Json.Default.Action, TargetConversionType = ConversionType.XML2Json }
            );

            routes.MapRoute(
            name: Rt.Xml2Csharp.Name,
            url: Rt.Xml2Csharp.Url,
            defaults: new { controller = Rt.Xml2Csharp.Default.Controller, action = Rt.Xml2Csharp.Default.Action, TargetConversionType = ConversionType.XML2Csharp }
            );

            routes.MapRoute(
            name: Rt.Xml2Html.Name,
            url: Rt.Xml2Html.Url,
            defaults: new { controller = Rt.Xml2Html.Default.Controller, action = Rt.Xml2Html.Default.Action, TargetConversionType = ConversionType.XML2HTML }
            );

            routes.MapRoute(
            name: Rt.Default.Name,
            url: Rt.Default.Url,
            defaults: new { controller = Rt.Default.Default.Controller, action = Rt.Default.Default.Action, TargetConversionType = ConversionType.All}
            );
        }
    }
}