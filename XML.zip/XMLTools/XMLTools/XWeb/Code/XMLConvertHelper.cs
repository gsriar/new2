﻿#region using
using System;
using System.IO;
using System.Text;
using System.Web;
using System.Xml.Linq;
using X2CS;
using X2SQL;
using XPassThrough;
using XWeb.Models;
#endregion

namespace XWeb.Code
{
    public class XMLConvertHelper
    {
       public static XMLConvertHelper Instance = new XMLConvertHelper();
       private System.Net.WebClient wc = new System.Net.WebClient();

        #region helper methods
        public StreamReader GetURLStreamReader(string url)
        {
            try
            {                
                return new StreamReader(wc.OpenRead(url));
            }
            catch { throw new Exception("Unable to read from URL"); }
        }

        public StreamReader GetPostedFileStream(HttpPostedFileBase postedFile)
        {
            try
            {
                if (postedFile.ContentLength > 0 && (postedFile.ContentType.ToLower() == "text/xml" || postedFile.ContentType.ToLower() == "application/xml"))
                {
                    return new StreamReader(postedFile.InputStream);                    
                }
                else
                {
                    throw new Exception("Attachment is not an XML File");
                }
            }
            catch { throw new Exception("Unable to load attchment file"); }
        }

        public StreamReader GetXMLTextReader(XData model)
        {
            bool set = false;

            StreamReader reader = null;
            if (model.XmlAttachment != null)
            {  
                reader = GetPostedFileStream(model.XmlAttachment);
                set = true;
            }

            if (!set && model.XmlUrl != null)
            {
                reader= GetURLStreamReader(model.XmlUrl);
                set = true;
            }

            if(!set && string.IsNullOrWhiteSpace(model.XML))
            {
                throw new Exception("XML not found.. choose source XML first");
            }

            reader = set ? reader : new StreamReader(GenerateStreamFromString(model.XML));

            if (reader.BaseStream.Length > (1 * 1000000))
            {
                reader.Dispose();
                throw new Exception("XML size larger than 1 MB not curretly supported");
            }

            return reader;
        }

        public Stream GenerateStreamFromString(string s)
        {
            return new MemoryStream(Encoding.UTF8.GetBytes(s));
        }


        #endregion

        #region converter

        public XData Convert(XData model, TextWriter writer)
        {
             bool error = false;

             try
             {
                 using (var sr = GetXMLTextReader(model))
                 {
                     XDocument xmldoc = XDocument.Load(sr);
                     switch (model.TargetConversionType)
                     {
                         case ConversionType.XML2Csharp:
                             {
                                 CharacterCasingOption option = new CharacterCasingOption() { CharCaseType = CharaterCaseType.Pascal };
                                 XML2CS xml2cs = new XML2CS(xmldoc);
                                 xml2cs.Print(xmldoc, writer, option, model.OutputType);
                                 model.Brush = "csharp";
                             }                           
                             break;
                         case ConversionType.XML2SQL:
                             {
                                 CharacterCasingOption option = new CharacterCasingOption() { CharCaseType = CharaterCaseType.Pascal };
                                 TransformationOption transformationOption = new TransformationOption();

                                 transformationOption.DefinitionOption.PrimaryKeyOptions.AutoGeneratePrimaryKey = model.AutoGeneratePrimaryKey;
                                 transformationOption.DefinitionOption.ForeignKeyOptions.GenerateReferenceForeignKeys = model.AutoGenerateForeignKey;
                                 transformationOption.CharacterCasingOption = option;
                                 X2SQL.X2SQL.Instance.BuildSQL(xmldoc, transformationOption, writer);
                                 model.Brush = "sql";
                             }
                             break;
                         case ConversionType.XML2Json:
                             {
                                 X2JSON.JsonWrite jsonwriter = new X2JSON.JsonWrite();
                                 jsonwriter.BuildJson(xmldoc, writer); ;
                             }
                             break;
                         case ConversionType.XML2HTML:
                             {
                                 X2HTML.X2H htmlWriter = new X2HTML.X2H(HttpContext.Current.Server.MapPath("~/content"), xmldoc, writer);
                                 htmlWriter.HTMLParse();
                                 model.Brush = "json";
                             }
                             break;
                     }
                 }
             }
             catch (Exception ex)
             {
                 model.Conversion = ex.ToCustomMessage();
                 writer.Write(ex.ToCustomMessage());
                 error = true;
             }
             model.Dump(HttpContext.Current.Server.MapPath(Constants.Folder.Dump), error);
          
             
            return model;
        }


        #endregion
    }

}