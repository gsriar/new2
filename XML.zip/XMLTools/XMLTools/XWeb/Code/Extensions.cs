﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using XWeb.Models;

namespace XWeb
{
    public static class Extensions
    {
        public static string ToCustomMessage(this Exception ex)
        {
            return "SERVER ERROR: " + Environment.NewLine + ex.Message + Environment.NewLine;// +Environment.NewLine + ex.StackTrace;
        }

        public static void Dump(this XData data, string dir, bool isError)
        {
            try
            {
                string dateDir = DateTime.Now.ToString("ddMMMyy");
                
                dir = Path.Combine(dir, isError ? "ERROR" : "SUCCEED");

                dir = Path.Combine(dir, dateDir);

                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                string name = "";
                string timeStamp = DateTime.Now.ToUniversalTime().ToString("HHmmssfff_");
                //if (data.ProcessingXML != null)
                //{
                //    File.WriteAllText(Path.Combine(dir, timeStamp + name + ".source.xml"), data.ProcessingXML);
                //}
                //if (data.Conversion != null)
                //{
                //    File.WriteAllText(Path.Combine(dir, timeStamp + name + ".result.txt"), data.Conversion);
                //}

                File.WriteAllText(Path.Combine(dir, timeStamp + name + ".options.txt"),
                    string.Format("PK:{0},FK:{1}", data.AutoGeneratePrimaryKey, data.AutoGenerateForeignKey));
            }
            catch
            {
            }
        }

    }
}