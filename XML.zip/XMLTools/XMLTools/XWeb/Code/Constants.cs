﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace XWeb
{
    public static class Constants
    {
        public static class Folder
        {
            public const string Meta = "~/Admin/Meta";
            public const string Dump = "~/Admin/Dump";
            public const string Admin = "~/Admin";
            public const string Root = "~";
        }

        public static class Files
        {
            public const string Users = "Users.xml";
            public const string Description = "Description.txt";
            public const string Keywords = "Keywords.txt";
        }

    }

   
}