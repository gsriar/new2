﻿using System;
using System.Collections.Generic;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace Xml2CS
{
    [XmlRoot(ElementName = "MetaInfo")]
    [Serializable]
    public class MetaInfo
    {
        [XmlElement(ElementName = "ValueConstant")]
        public List<ValueConstant> ValueConstant { get; set; }

        [XmlElement(ElementName = "Resource")]
        public List<Resource> Resource { get; set; }

        [XmlElement(ElementName = "Page")]
        public List<Page> Page { get; set; }

    }

    [XmlRoot(ElementName = "ValueConstant")]
    [Serializable]
    public class ValueConstant
    {
        [XmlAttribute(AttributeName = "Key")]
        public string KEY { get; set; }

        [XmlAttribute(AttributeName = "Value")]
        public string Value { get; set; }

    }

    [XmlRoot(ElementName = "Resource")]
    [Serializable]
    public class Resource
    {
        [XmlAttribute(AttributeName = "Key")]
        public string KEY { get; set; }

        [XmlAttribute(AttributeName = "Type")]
        public string Type { get; set; }

        [XmlAttribute(AttributeName = "URI")]
        public string URI { get; set; }

    }

    [XmlRoot(ElementName = "Page")]
    [Serializable]
    public class Page
    {
        [XmlAttribute(AttributeName = "Key")]
        public string KEY { get; set; }

        [XmlElement(ElementName = "Introduction")]
        public string Introduction { get; set; }

        [XmlElement(ElementName = "Title")]
        public string Title { get; set; }

        [XmlElement(ElementName = "Description")]
        public string Description { get; set; }

        [XmlElement(ElementName = "Keywords")]
        public string Keywords { get; set; }

        [XmlElement(ElementName = "MetaTag")]
        public List<MetaTag> MetaTag { get; set; }

    }

    [XmlRoot(ElementName = "MetaTag")]
    [Serializable]
    public class MetaTag
    {
        [XmlAttribute(AttributeName = "Tag")]
        public string TAG { get; set; }

        [XmlAttribute(AttributeName = "Value")]
        public short Value { get; set; }

    }

}
