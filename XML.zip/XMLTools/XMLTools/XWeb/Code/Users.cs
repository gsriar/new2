﻿using System;
using System.Collections.Generic;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace Xml2CS
{
    [XmlRoot(ElementName = "Users")]
    [Serializable]
    public class Users
    {
        [XmlElement(ElementName = "User")]
        public List<User> User { get; set; }

    }

    [XmlRoot(ElementName = "User")]
    [Serializable]
    public class User
    {
        [XmlAttribute(AttributeName = "Key")]
        public string _KEY { get; set; }

        [XmlAttribute(AttributeName = "Name")]
        public string Name { get; set; }

    }

} 

