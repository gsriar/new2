﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SharedHelper;

namespace XWeb
{
    public class DP
    {
        public static readonly DP Me = new DP();
        private Dictionary<string, Xml2CS.Page> PageHash = null;
        private Dictionary<string, string> ValueConstantHashtable = null;
        private string FilePath;
        private Xml2CS.MetaInfo metaInfo { get; set; }

        private DP()
        {
            string dir=HttpContext.Current.Server.MapPath("~");
            FilePath = System.IO.Path.Combine(dir, "Admin/metadata.xml");
            Load();
        }

        private void Load()
        {
            metaInfo = SharedHelper.SerializationHelper.Deserialize<Xml2CS.MetaInfo>(FilePath);

            PageHash = new Dictionary<string, Xml2CS.Page>();
            foreach (var page in metaInfo.Page)
            {
                PageHash.Add(page.KEY, page);
            }


            ValueConstantHashtable = new Dictionary<string, string>();
            foreach (var page in metaInfo.ValueConstant)
            {
                ValueConstantHashtable.Add(page.KEY, page.Value);
            }

        }

        public Xml2CS.Page Page(string key)
        {
            if (PageHash.ContainsKey(key))
                return PageHash[key];
            else
                return null;
        }

        public string ValueConstant(string key)
        {
            if (ValueConstantHashtable.ContainsKey(key))
                return ValueConstantHashtable[key];
            else
                return string.Empty;

        }

        public Xml2CS.Resource Resource(string key)
        {
            return this.metaInfo.Resource.FirstOrDefault(f => f.KEY == key);
        }

    }
}