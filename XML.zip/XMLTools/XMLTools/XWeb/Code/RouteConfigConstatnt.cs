﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace XWeb.Code
{
    public class ControllerAction
    {
        public ControllerAction(string controller, string action)
        {
            this.Controller = controller;
            this.Action = action;
        }

        public string Controller { get; private set; }

        public string Action { get; private set; }
    }

    public class RouteInfo
    {
        public RouteInfo(string route, string url,ControllerAction controlAction)
        {
            this.Url = url;
            this.Name = route;
            Default = controlAction;
        }
        public string Name { get; set; }
        public string Url { get; set; }
        public ControllerAction Default { get; private set; }
    }

   


}