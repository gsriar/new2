﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace XWeb
{
    public class GlobalHelper
    {
        public static readonly GlobalHelper Instance = new GlobalHelper();
        public MetaInfo MetaInfo = new MetaInfo();
       
        private GlobalHelper()
        {
            LoadMetaData();
        }

        public void LoadMetaData()
        {
            string serverpath = HttpContext.Current.Server.MapPath(Constants.Folder.Meta);

            List<string> DescriptionsList = new List<string>(File.ReadAllLines(Path.Combine(serverpath, Constants.Files.Description)));

            List<string> Keywords = new List<string>(File.ReadAllLines(Path.Combine(serverpath, Constants.Files.Keywords)));

            MetaInfo.Keywords = string.Format("<meta name=\"keywords\" content=\"{0}\"/>", SharedHelper.StringHelper.ConcatFormat(Keywords, ", ", null, null));

            MetaInfo.Description = string.Format("<meta name=\"description\" content=\"{0}\"/>", SharedHelper.StringHelper.ConcatFormat(DescriptionsList, ", ", null, null));
        }
    }

    public class MetaInfo
    {
        public string Keywords { get; set; }

        public string Description { get; set; }
    }
}