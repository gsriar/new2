﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using XWeb.Code;
using XWeb.Models;

namespace XWeb.Controllers
{
    public partial class XMLController : Controller
    {
        public virtual ActionResult Convert(ConversionType TargetConversionType)
        {
            XData data = new XData();
            data.Brush = "csharp";
            data.TargetConversionType = TargetConversionType;
            switch (TargetConversionType)
            {
                case ConversionType.XML2Csharp:
                    ViewBag.menu = "csharp";
                    break;

                case ConversionType.XML2HTML:
                    ViewBag.menu = "html";
                    break;

                case ConversionType.XML2Json:
                    ViewBag.menu = "json";
                    break;

                case ConversionType.XML2SQL:
                    ViewBag.menu = "sql";
                    break;
            }
            


            return View(MVC.XmlUtil.Views.XmlToCode, data);
        }

        [HttpPost]
        [ValidateInput(false)]
        public virtual ActionResult Convert(XData model)
        {
           
            Response.ContentType = "text/plain";
            XMLConvertHelper.Instance.Convert(model, Response.Output);
            return new EmptyResult();
        }

    }
}
