﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using XWeb.Models;

namespace XWeb.Controllers
{
    public partial class TestBedController : Controller
    {
        public virtual ActionResult FileUpload()
        {
            Upload upload = new Upload();
            return View(upload);
        }

        [HttpPost]
        [ValidateInput(false)]
        public virtual ActionResult FileUpload(Upload upload)
        {
            string keys = "";
            foreach (var k in Request.Params.AllKeys)
            {
                keys += k + Environment.NewLine;
            }
            foreach (string key in Request.Files.AllKeys)
            {
                HttpPostedFileBase f = Request.Files[key];
            }
            var v = Request["0"];
            upload.XmlUrl = "test";
            return View(upload);
        }

    }
}
