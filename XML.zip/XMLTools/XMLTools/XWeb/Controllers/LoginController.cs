﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace XWeb.Controllers
{
    public partial class LoginController : Controller
    {
        public virtual ActionResult Index()
        {
            return View(MVC.Login.Views.Login);
        }

        [HttpPost]
        public virtual ActionResult LogIn(Models.User user)
        {
            string roles = "Admin,Member";
            FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
              1,
              "Gurbhej",  //user id
              DateTime.Now,
              DateTime.Now.AddMinutes(20),  // expiry
              false,  //do not remember
              roles,
              "/");
            HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(authTicket));
            Response.Cookies.Add(cookie);
            return View(MVC.XmlUtil.Views.Index);

        }
    }
}
