﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace XWeb.Controllers
{
    public partial class ConvertCSVController : Controller
    {
        //
        // GET: /CSVConvert/

        public virtual ActionResult Index()
        {
            return View();
        }


        public virtual ActionResult CSV2SQLScript()
        {
            return View();
        }

        public virtual ActionResult CSV2HTMLTABLE()
        {
            return View();
        }
    }
}
