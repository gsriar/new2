﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace XWeb.Controllers
{
    public partial class JsonTestController : Controller
    {
        //
        // GET: /JsonTest/

        public virtual ActionResult Index()
        {
            return View();
        }

    }
}
