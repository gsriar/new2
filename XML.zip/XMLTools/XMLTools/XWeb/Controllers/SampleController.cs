﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.Ajax.Utilities;

namespace XWeb.Controllers
{
    public partial class SampleController : Controller
    {
        public virtual ActionResult Xml()
        {
            string file = Path.Combine(Server.MapPath("~"), "SampleXml", "Sample1.xml");

            return new FileStreamResult(System.IO.File.OpenRead(file), "text/plain");
        }


        public virtual ActionResult DirectWrite()
        {
            Response.Write("hi");
            //HttpContext.ApplicationInstance.CompleteRequest();

            return View();     // does not execute!
        }

        public virtual ActionResult RobotsText()
        {
            Response.ContentType = "text/plain";
            Response.Write("User-agent: *\r\nAllow: /");
            return new EmptyResult();
        }

        public virtual FileStreamResult CreateReport(string report, string writer)
        {
            var stream = new MemoryStream();
            var streamWriter = new StreamWriter(stream);

            // _generateReport.GenerateReport(report, writer);

            streamWriter.Flush();
            stream.Seek(0, SeekOrigin.Begin);

            return new FileStreamResult(stream, "text/plain");
        }

        public virtual ActionResult CreateReport1()
        {
            var serverPipe = new AnonymousPipeServerStream(PipeDirection.Out);

            var clientPipe = new AnonymousPipeClientStream(PipeDirection.In,
                     serverPipe.ClientSafePipeHandle);
            return new FileStreamResult(clientPipe, "text/csv");
        }

        public virtual FileResult Download()
        {
            string file = Path.Combine(Server.MapPath("~"), "SampleXml", "Sample1.xml");
            byte[] fileBytes = System.IO.File.ReadAllBytes(file);
            string fileName = "myfile.ext";
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }
    }
}
