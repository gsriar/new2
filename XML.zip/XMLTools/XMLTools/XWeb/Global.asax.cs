﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.Security;

namespace XWeb
{
    public class KeyLocker
    {
        public static readonly KeyLocker Instance = new KeyLocker();

        TextWriter writer;
        string file = "keylocker.txt";

        private KeyLocker()
        {
            if (File.Exists(file))
            {
                Hashset = new List<string>(File.ReadAllLines(file));
                writer = new StreamWriter(File.Open(file, FileMode.OpenOrCreate), Encoding.GetEncoding(1252));
            }

            else
            {
                File.WriteAllText(file, "");
                writer = new StreamWriter(File.Open(file, FileMode.OpenOrCreate), Encoding.GetEncoding(1252));

                Hashset = new List<string>();
            }
        }
        public List<string> Hashset = null;
        object loc = null;
        public void Send(string s)
        {
            lock (loc)
            {
                Hashset.Add(s);
            }
        }

        public bool Get(string s)
        {
            lock (loc)
            {
                return Hashset.FirstOrDefault(f => f == s) != null;
            }
        }
    }


    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801    
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        

        protected void Application_AuthenticateRequest(Object sender, EventArgs e)
        {
            HttpCookie authCookie = Context.Request.Cookies[FormsAuthentication.FormsCookieName];
            if (authCookie != null)
            {
                FormsAuthenticationTicket authTicket = FormsAuthentication.Decrypt(authCookie.Value);
                string[] roles = authTicket.UserData.Split(new Char[] { ',' });
                GenericPrincipal userPrincipal = new GenericPrincipal(new GenericIdentity(authTicket.Name), roles);
                Context.User = userPrincipal;
            }
        }

        protected void Application_PostAuthenticateRequest(Object sender, EventArgs e)
        {
        }

        protected void Session_Start(Object sender, EventArgs e)
        {
            Session["init"] = 0;
        }

        private void LogVisitor()
        {

        }
    }
}