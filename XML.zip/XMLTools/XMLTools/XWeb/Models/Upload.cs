﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace XWeb.Models
{
    public class Upload
    {
        [Display(Name = "Browse a File")]
        public HttpPostedFileBase XmlAttachment { get; set; }

        [Display(Name = "Paste web URL")]
        public string XmlUrl { get; set; }
    }
}