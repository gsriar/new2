﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using X2CS.Shared;

namespace XWeb.Models
{
    public enum ConversionType
    {
        All,
        XML2Csharp,
        XML2SQL,
        XML2Json,
        XML2HTML,
    }

    public class XData
    {
        public OutputTypeEnum OutputType { get; set; }

        
        public string Conversion { get; set; }

        public string AdditionalInfo { get; set; }

        public string Brush { get; set; }

        [Display(Name = "Auto-Generate Primary Key")]
        public Boolean AutoGeneratePrimaryKey { get; set; }

        [Display(Name = "Auto-Generate ForeignKey Relation")]
        public Boolean AutoGenerateForeignKey { get; set; }

        [Display(Name = "Character Casing Option")]
        public string CharacterCasing { get; private set; }

        [Display(Name = "(Option #1) Select a File")]
        public HttpPostedFileBase XmlAttachment { get; set; }

        [Display(Name = "(Option #2) Paste plain XML")]
        public string XML { get; set; }

        [Display(Name = "(Option #3) Paste web URL")]
        public string XmlUrl { get; set; }
      
        public ConversionType TargetConversionType { get; set; }
    }
}

