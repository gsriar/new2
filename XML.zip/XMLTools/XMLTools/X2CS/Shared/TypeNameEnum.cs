﻿
namespace X2CS.Enums
{
    public enum TypeEnum
    {
        Class,
        Struct,
        Interface
    }
}
