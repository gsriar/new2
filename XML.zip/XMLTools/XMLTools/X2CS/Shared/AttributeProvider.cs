﻿using System;
using System.Xml.Schema;
using X2CS.Fixture;
using XPassThrough;

namespace X2CS.Write
{
    public static class AttributeProvider
    {
        const string XmlSchemaForm = "XmlSchemaForm.Qualified";

        static public MemberAttributeFixture XmlRoot(string value, string _namespace = null)
        {
            var r = new MemberAttributeFixture() { Name = "XmlRoot" };
            r.AttributeCollection.Add(new Tuple<string, string, bool>("ElementName", value, true));
            if (!string.IsNullOrEmpty(_namespace))
            {
                r.AttributeCollection.Add(new Tuple<string, string, bool>("Namespace", _namespace, true));
            }
            return r;
        }

        static public MemberAttributeFixture XmlRoot(QualifiedName qname)
        {
            return XmlRoot(qname.Name, qname.NameSpace);
        }

        static public MemberAttributeFixture XmlAttribute(string value, string _namespace = null, bool ns = true)
        {
            var r = new MemberAttributeFixture() { Name = "XmlAttribute" };
            r.AttributeCollection.Add(new Tuple<string, string, bool>("AttributeName", value, true));

            if (!string.IsNullOrEmpty(_namespace))
            {
                if (ns)
                    r.AttributeCollection.Add(new Tuple<string, string, bool>("Namespace", _namespace, true));

                r.AttributeCollection.Add(new Tuple<string, string, bool>("Form", XmlSchemaForm, false));
            }
            return r;
        }

        static public MemberAttributeFixture XmlAttribute(QualifiedName qname, bool ns = true)
        {
            return XmlAttribute(qname.Name, qname.NameSpace, ns);
        }

        static public MemberAttributeFixture XmlElement(string value, string _namespace = null, bool ns = true)
        {
            var r = new MemberAttributeFixture() { Name = "XmlElement" };
            r.AttributeCollection.Add(new Tuple<string, string, bool>("ElementName", value, true));

            if (!string.IsNullOrEmpty(_namespace))
            {
                if (ns)
                    r.AttributeCollection.Add(new Tuple<string, string, bool>("Namespace", _namespace, true));

                r.AttributeCollection.Add(new Tuple<string, string, bool>("Form", XmlSchemaForm, false));
            }

            return r;
        }

        static public MemberAttributeFixture XmlElement(QualifiedName qname, bool ns = true)
        {
            return XmlElement(qname.Name, qname.NameSpace, ns);
        }

        static public MemberAttributeFixture XmlText()
        {
            var r = new MemberAttributeFixture() { Name = "XmlText" };
            return r;
        }
    }
}
