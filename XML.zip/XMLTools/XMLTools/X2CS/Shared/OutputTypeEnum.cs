﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace X2CS.Shared
{
    public enum OutputTypeEnum
    {
        [Description("Generate Serializable ")]
        Serializable,
        [Description("Generate DataContract")]
        DataContract,
        [Description("Generate POCO")]
        POCO
    }
}
