using System;

namespace X2CS.Enums
{
    public enum TypeMemberEnum
	{
		Event,
		Field,
		NestedType,
		Method,
		Property
	}
}
