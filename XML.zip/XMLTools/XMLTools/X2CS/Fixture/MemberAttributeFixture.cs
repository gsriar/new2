using System;
using System.Collections.Generic;
using X2CS.Shared;

namespace X2CS.Fixture
{
    public class MemberAttributeFixture : CodeElement
    {
        public MemberAttributeFixture()
        {
            AttributeCollection = new List<Tuple<string, string, bool>>();
        }

        public List<Tuple<string, string, bool>> AttributeCollection
        {
            get;
            set;
        }

    }
}
