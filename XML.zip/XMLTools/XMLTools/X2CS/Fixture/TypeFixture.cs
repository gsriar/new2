using System.Collections.Generic;
using System.Runtime.Serialization;
using X2CS.Enums;
using X2CS.Shared;

namespace X2CS.Fixture
{
    [DataContract(Namespace = "http://Microsoft.ServiceModel.Samples")]
    public class TypeFixture : CodeElement
	{
        public TypeFixture()
        {
            MemberAttributeCollection = new List<MemberAttributeFixture>();
            TypeMemberCollection = new List<TypeMemberFixture>();
        }

		public string _access = "public";

		public string AccessModifier
		{
			get
			{
				return this._access;
			}
			set
			{
				this._access = value;
			}
		}

        public TypeEnum TypeName
        {
            get;
            set;
        }

        public static string DefaultValue { get; set; }

        public List<MemberAttributeFixture> MemberAttributeCollection
		{
			get;
			set;
		}

		public List<TypeMemberFixture> TypeMemberCollection
		{
			get;
			set;
		}

        public override IEnumerable<CodeElement> ChildCollection
        {
            get { return TypeMemberCollection; }
        }

        public override IEnumerable<CodeElement> PeerCollection
        {
            get { return MemberAttributeCollection; }
        }
        
	}
}
