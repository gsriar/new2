using System;
using System.Collections.Generic;
using System.Text;
using X2CS.Shared;

namespace X2CS.Fixture
{
    public class NamespaceFixture : CodeElement
	{
        public NamespaceFixture()
        {
            TypeFixtureCollection = new List<TypeFixture>();
            UsingCollection = new List<string>();
        }

        public List<string> UsingCollection
        {
            get;
            set;
        }

        public List<TypeFixture> TypeFixtureCollection
		{
			get;
			set;
		}


        public List<MemberAttributeFixture> MemberAttributeCollection
        {
            get;
            set;
        }

        public override IEnumerable<CodeElement> PeerCollection
        {
            get
            {
                return MemberAttributeCollection;
            }
        }

        public override IEnumerable<CodeElement> ChildCollection
        {
            get { return TypeFixtureCollection; }
        }

	}
}
