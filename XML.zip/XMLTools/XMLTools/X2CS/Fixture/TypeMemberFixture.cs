using System;
using System.Collections.Generic;
using System.Text;
using X2CS.Enums;
using X2CS.Shared;

namespace X2CS.Fixture
{
    public class TypeMemberFixture : CodeElement
	{
        public TypeMemberFixture()
        {
            MemberAttributeCollection = new List<MemberAttributeFixture>();
        }

		public string _access = "public";

		public TypeMemberEnum MemberType
		{
			get;
			set;
		}

		public string Type
		{
			get;
			set;
		}

        public string CollectionType
        {
            get;
            set;
        }

		public string AccessModifier
		{
			get
			{
				return this._access;
			}
			set
			{
				this._access = value;
			}
		}

        public List<MemberAttributeFixture> MemberAttributeCollection
		{
			get;
			set;
		}

        public override IEnumerable<CodeElement> PeerCollection
        {
            get { return MemberAttributeCollection; }
        }

	}
}
