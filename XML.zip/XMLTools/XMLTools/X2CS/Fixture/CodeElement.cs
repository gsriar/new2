using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace X2CS.Shared
{
    public abstract class CodeElement
    {
        public string Name
        {
            get;
            set;
        }

        public virtual IEnumerable<CodeElement> ChildCollection
        {
            get
            {
                yield break;
            }
        }

        public virtual IEnumerable<CodeElement> PeerCollection
        {
            get
            {
                yield break;
            }
        }

        public void Write(CodeWriterFormat formatterIdentifier, TextWriter textWriter, int indent = 0)
        {
            this.Write(CodeWriterFactory.Get(formatterIdentifier, textWriter), indent);
        }

        public void Write(ICodeWriter writer, int indent = 0)
        {
            writer.WriteCode(this, indent);
        }

        public string ToCodeString(CodeWriterFormat codeFormatIdentifier, TextWriter textWriter)
        {
            this.Write(CodeWriterFactory.Get(codeFormatIdentifier, textWriter), 0);
            return textWriter.ToString();
        }
    }
}
