﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using X2CS.Fixture;
using X2CS.Shared;
using X2CS.Write;
using XPassThrough;

namespace X2CS
{
    public class X2CodeConstant
    {
        private XDocument xml;

        public X2CodeConstant(XDocument xdoc)
        {
            xml = xdoc;
        }

        public string Print(XDocument xml, TextWriter txtWr, CharacterCasingOption characterCasingOption, OutputTypeEnum outputType = OutputTypeEnum.None)
        {
            XTree nodeTree = XTreeBuilder.Instance.BuidCleanXTree(xml, characterCasingOption);
            var writer = BuildCodeTree(nodeTree, outputType);
            return writer.ToCodeString(CodeWriterFormat.CSharp, txtWr);
        }


        public static CodeElement BuildCodeTree(XTree nodeTree, OutputTypeEnum outputType = OutputTypeEnum.None)
        {
            NamespaceFixture namespaceFixture = new NamespaceFixture() { Name = "XC" };
            namespaceFixture.UsingCollection.Add("System");
            namespaceFixture.UsingCollection.Add("System.Collections.Generic");

            foreach (var treeNode in nodeTree.NodeCollection)
            {
                TypeFixture classFixture = new TypeFixture() { Name = treeNode.QualifiedName.Name, TypeName = Enums.TypeEnum.Class };
                namespaceFixture.TypeFixtureCollection.Add(classFixture);

                int i = 0;
                foreach (XPassThrough.Attribute att in treeNode.AttributeCollection)
                {
                    SharedHelper.DataInfoResolve.DataInfo dataInfo = SharedHelper.DataInfoResolve.Resolve(att.ValueCollection);

                    var typeClassMember = new TypeMemberFixture() { Name = att.QualifiedName.Name, Type = dataInfo.Type.ToString(), MemberType=Enums.TypeMemberEnum.Field };
                    
                    while (typeClassMember.Name == classFixture.Name)
                        typeClassMember.Name = typeClassMember.Name + (++i);

                    classFixture.TypeMemberCollection.Add(typeClassMember);
                }

                i = 0;
                foreach (var treeNodeSibling in treeNode.ChidInfoCollection)
                {
                    var typeClassComplexMember = new TypeMemberFixture()
                    {
                        Name = treeNodeSibling.QualifiedName.Name,
                        Type = treeNodeSibling.QualifiedName.Name,
                        CollectionType = (treeNodeSibling.Count > 1 ? "List" : null)
                    };
                    
                    while (typeClassComplexMember.Name == classFixture.Name)
                        typeClassComplexMember.Name = typeClassComplexMember.Name + (++i);

                    classFixture.TypeMemberCollection.Add(typeClassComplexMember);
                }

                if (treeNode.InnerTextCollection.Count > 0 && outputType == Shared.OutputTypeEnum.XML)
                {
                    var propertyAttribute = AttributeProvider.XmlText();
                    var innerText = "Text";
                    int count = 0;

                    while (classFixture.TypeMemberCollection.FirstOrDefault(c => c.Name.IndexOf(innerText, StringComparison.OrdinalIgnoreCase) > -1) != null)
                    {
                        innerText += count++;
                    }

                    var typeClassInnerTextMember = new TypeMemberFixture() { Name = innerText, Type = "System.String" };
                    typeClassInnerTextMember.MemberAttributeCollection.Add(propertyAttribute);
                    classFixture.TypeMemberCollection.Add(typeClassInnerTextMember);
                }
            }
            return namespaceFixture;
        }
    }
}
