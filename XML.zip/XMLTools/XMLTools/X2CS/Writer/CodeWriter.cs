using System;
using System.Collections.Generic;
using System.IO;
using X2CS.Fixture;

namespace X2CS.Shared
{
	public abstract class CodeWriter : ICodeWriter
	{
        protected const string curlyOpen = "{";

        protected const string curlyClose = "}";

        protected const string roundOpen = "(";

        protected const string roundClose = ")";

        protected const string squareOpen = "[";

        protected const string squareClose = "]";

        protected const string equalSign = "=";

        protected const string semicolon = ";";

        protected const string doubleQuote = "\"";

        protected TextWriter writer = null;

		public CodeWriter(TextWriter sb)
		{
			this.writer = sb;
		}

		public void LeftIndent(int indent)
		{
			this.writer.Write(string.Empty.PadLeft(indent,'\t'));
		}

		protected abstract void WriteCode(TypeMemberFixture member, int indent);

		protected abstract void WriteCode(TypeFixture member, int indent);

		protected abstract void WriteCode(MemberAttributeFixture member, int indent);

		protected abstract void WriteCode(NamespaceFixture member, int indent);

        public void WriteCode(CodeElement member, int indent)
		{
			if (member is TypeFixture)
			{
				this.WriteCode(member as TypeFixture, indent);
			}
			else if (member is MemberAttributeFixture)
			{
				this.WriteCode(member as MemberAttributeFixture, indent);
			}
			else if (member is NamespaceFixture)
			{
				this.WriteCode(member as NamespaceFixture, indent);
			}
			else
			{
				if (!(member is TypeMemberFixture))
				{
					throw new Exception("Code Element not Implemented");
				}
				this.WriteCode(member as TypeMemberFixture, indent);
			}
		}

		public void WriteCode(IEnumerable<CodeElement> collection, int indent)
		{ 
			if (collection != null)
			{
				foreach (CodeElement col in collection)
				{
					col.Write(this, indent);
				}
			}
		}

		public void WriteIndentLine(int indent, params string[] words)
		{
			this.LeftIndent(indent);
			this.AppendWords(words);
			this.WriteLine();
		}

		public void WriteLine()
		{
			this.writer.WriteLine("");
		}

		public void Append(string text)
		{
			this.writer.Write(text);
		}

		public void WriteLines(int indent, params string[] text)
		{
			if (text != null)
			{
				for (int i = 0; i < text.Length; i++)
				{
					string s = text[i];
					this.WriteIndentLine(indent, new string[]
					{
						s
					});
				}
			}
		}

		public void AppendWords(params string[] text)
		{
			if (text != null)
			{
				for (int i = 0; i < text.Length; i++)
				{
					string s = text[i];
					this.writer.Write(s);
					this.writer.Write(' ');
				}
			}
		}

		public void WriteFormatedLine(string Format, params string[] args)
		{
			if (args != null)
			{
				this.writer.WriteLine(Format, args);
			}
		}
	}
}
