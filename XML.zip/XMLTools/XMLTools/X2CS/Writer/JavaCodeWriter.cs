﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using X2CS.Shared;

namespace X2CS
{
    class JavaCodeWriter : CodeWriter
    {
        public JavaCodeWriter(TextWriter sb)
            : base(sb)
        {
        }
        protected override void WriteCode(Fixture.TypeMemberFixture member, int indent)
        {
            throw new NotImplementedException();
        }

        protected override void WriteCode(Fixture.TypeFixture member, int indent)
        {
            throw new NotImplementedException();
        }

        protected override void WriteCode(Fixture.MemberAttributeFixture member, int indent)
        {
            throw new NotImplementedException();
        }

        protected override void WriteCode(Fixture.NamespaceFixture member, int indent)
        {
            throw new NotImplementedException();
        }
    }
}
