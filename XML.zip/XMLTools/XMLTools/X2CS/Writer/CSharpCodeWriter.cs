using System;
using System.IO;
using X2CS.Fixture;
using X2CS.Shared;
using SharedHelper;

namespace X2CS.Shared
{
    internal class CSCodeWriter : CodeWriter
    {
        private const string get = "get";

        private const string set = "set";

        private const string USING = "using";

        private const string NAMESPACE = "namespace";

        public CSCodeWriter(TextWriter sb)
            : base(sb)
        {
        }

        protected override void WriteCode(NamespaceFixture member, int indent)
        {            
            base.WriteCode(member.PeerCollection, indent);
            if (member.UsingCollection != null)
            {
                member.UsingCollection.ForEach(delegate(string mem)
                {
                    this.WriteIndentLine(indent, new string[]
					{
						USING,
						mem,
						semicolon
					});
                });
                base.WriteLine();
            }
            base.WriteIndentLine(indent, new string[]
			{
				NAMESPACE,
				member.Name
			});
            base.WriteIndentLine(indent, new string[]
			{
				curlyOpen
			});
            base.WriteCode(member.ChildCollection, indent + 1);
            base.WriteIndentLine(indent, new string[]
			{
				curlyClose
			});
        }

        protected override void WriteCode(TypeFixture member, int indent)
        {
            base.WriteCode(member.PeerCollection, indent);

            base.WriteIndentLine(indent, new string[]
			{
				member.AccessModifier,
				member.TypeName.ToString().ToLower(),
				member.Name.Replace("-", " ").ToProperCase().ToPascalCase()
			});
            base.WriteIndentLine(indent, new string[]
			{
				curlyOpen
			});
            base.WriteCode(member.ChildCollection, indent + 1);
            base.WriteIndentLine(indent, new string[]
			{
				curlyClose
			});
            base.WriteLine();
        }

        protected override void WriteCode(TypeMemberFixture member, int indent)
        {
            base.WriteCode(member.PeerCollection, indent);

            string typeName = "";
            if (Type.GetType(member.Type) == null)
            {
                typeName = member.Type;
            }
            else
            {
                typeName = TypeHelper.GetTypeAlias(member.Type);
            }

            if (member.CollectionType != null)
                typeName = string.Format("{0}<{1}>", member.CollectionType, typeName);
            
            base.WriteIndentLine(indent, new string[]
			{
				member.AccessModifier,
				typeName,
				member.Name ,//.ApplySQLNameConvention,
				curlyOpen,
				get,
				semicolon,
				set,
				semicolon,
				curlyClose
			});
            base.WriteLine();
        }

        protected override void WriteCode(MemberAttributeFixture member, int indent)
        {
            base.LeftIndent(indent);
            base.Append(squareOpen);
            base.Append(member.Name);
            if (member.AttributeCollection != null && member.AttributeCollection.Count>0)
            {
                base.Append(roundOpen);
                for (int i = 0; i < member.AttributeCollection.Count; i++)
                {
                    Tuple<string,string,bool> o = member.AttributeCollection[i];
                    base.AppendWords(new string[]
					{
						o.Item1,
						equalSign,
                        (o.Item3?doubleQuote:"")+o.Item2+(o.Item3?doubleQuote:""),
						(i < member.AttributeCollection.Count - 1) ? "," : ""
					});
                }
                base.Append(roundClose);
            }
            base.Append(squareClose);
            base.WriteLine();
        }
    }
}
