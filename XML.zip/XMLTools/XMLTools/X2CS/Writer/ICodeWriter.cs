using System;

namespace X2CS.Shared
{
	public interface ICodeWriter
	{
		void WriteCode(CodeElement member, int indent);
	}
}
