using System;

namespace X2CS.Shared
{
    public enum CodeWriterFormat
	{
		CSharp,
        Java
	}
}
