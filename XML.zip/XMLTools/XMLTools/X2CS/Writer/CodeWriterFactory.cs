using System;
using System.IO;

namespace X2CS.Shared
{
    internal class CodeWriterFactory
    {
        public static ICodeWriter Get(CodeWriterFormat formatterIdentifier, TextWriter txtWr)
        {
            switch (formatterIdentifier)
            {
                case CodeWriterFormat.CSharp:
                    return new CSCodeWriter(txtWr);
                case CodeWriterFormat.Java:
                    return new JavaCodeWriter(txtWr);
                default:
                    return null;
            }
        }
    }
}
