﻿using System;
using System.IO;
using System.Xml.Linq;
using X2CS.Fixture;
using X2CS.Shared;
using X2CS.Write;
using XPassThrough;
using System.Linq;

namespace X2CS
{
    public class XML2CS
    {
        private XDocument xml;

        public XML2CS(XDocument xdoc)
        {
            xml = xdoc;
        }

        public string Print(XDocument xml, TextWriter txtWr, CharacterCasingOption characterCasingOption, OutputTypeEnum outputType = OutputTypeEnum.POCO)
        {
            XMeta nodeTree = XTreeBuilder.Instance.BuidXTree(xml);
            nodeTree.CleanAndApplyQualifiedName(characterCasingOption);
            nodeTree.CleanAndApplyQualifiedName(characterCasingOption);

            var writer = BuildCodeTree(nodeTree, outputType);

            return writer.ToCodeString(CodeWriterFormat.CSharp, txtWr);
        }


        public static CodeElement BuildCodeTree(XMeta nodeTree, OutputTypeEnum outputType = OutputTypeEnum.POCO)
        {
            int i = 0;
            NamespaceFixture namespaceFixture = new NamespaceFixture() { Name = "Xml2CS" };
            namespaceFixture.UsingCollection.Add("System");
            namespaceFixture.UsingCollection.Add("System.Collections.Generic");

            switch (outputType)
            {
                case OutputTypeEnum.DataContract:
                    namespaceFixture.UsingCollection.Add("System.Runtime.Serialization");
                    break;
                case OutputTypeEnum.Serializable:
                    namespaceFixture.UsingCollection.Add("System.Xml.Schema");
                    namespaceFixture.UsingCollection.Add("System.Xml.Serialization");
                    break;
            }
            foreach (var treeNode in nodeTree.NodeCollection)
            {
                TypeFixture typeClass = new TypeFixture() { Name = treeNode.QualifiedName.CustomName, TypeName = Enums.TypeEnum.Class };
                namespaceFixture.TypeFixtureCollection.Add(typeClass);

                switch (outputType)
                {
                    case OutputTypeEnum.DataContract:
                        typeClass.MemberAttributeCollection.Add(new MemberAttributeFixture() { Name = "DataContract" });
                        break;
                    case OutputTypeEnum.Serializable:
                        var classAttribute = AttributeProvider.XmlRoot(treeNode.QualifiedName);
                        typeClass.MemberAttributeCollection.Add(classAttribute);
                        typeClass.MemberAttributeCollection.Add(new MemberAttributeFixture() { Name = "Serializable" });
                        break;
                }
                i = 0;
                foreach (XPassThrough.Attribute att in treeNode.AttributeCollection)
                {
                    SharedHelper.DataInfoResolve.DataInfo dataInfo = SharedHelper.DataInfoResolve.Resolve(att.AttributeValueCollection);

                    var typeClassMember = new TypeMemberFixture() { Name = att.QualifiedName.CustomName, Type = dataInfo.Type.ToString() };

                    switch (outputType)
                    {
                        case Shared.OutputTypeEnum.DataContract:
                            typeClassMember.MemberAttributeCollection.Add(new MemberAttributeFixture() { Name = "DataMember" });
                            break;
                        case Shared.OutputTypeEnum.Serializable:
                            bool nsAtt = !(att.QualifiedName.NameSpace == treeNode.QualifiedName.NameSpace);
                            var propertyAttribute = att.AttributeType == AttributeType.Element ? AttributeProvider.XmlElement(att.QualifiedName, nsAtt) : AttributeProvider.XmlAttribute(att.QualifiedName, nsAtt);
                            typeClassMember.MemberAttributeCollection.Add(propertyAttribute);
                            break;
                    }

                    while (typeClassMember.Name == typeClass.Name)
                        typeClassMember.Name = typeClassMember.Name + (++i);

                    typeClass.TypeMemberCollection.Add(typeClassMember);
                }
                i = 0;
                foreach (var treeNodeSibling in treeNode.ChidCollection)
                {                    
                    var mainNode=  nodeTree.NodeCollection.First(f=> f.QualifiedName.ShallowSame(treeNodeSibling.QualifiedName));
                    var typeClassComplexMember = new TypeMemberFixture()
                    {
                        Name = treeNodeSibling.QualifiedName.CustomName,
                        Type = treeNodeSibling.QualifiedName.CustomName,
                        //CollectionType = (mainNode.MaxParallelOccurance > 1 ? "List" : null)
                        CollectionType = "List"
                    };

                    switch (outputType)
                    {
                        case Shared.OutputTypeEnum.DataContract:
                            break;
                        case Shared.OutputTypeEnum.Serializable:
                            var propertyAttribute = AttributeProvider.XmlElement(treeNodeSibling.QualifiedName, !(treeNodeSibling.QualifiedName.NameSpace == treeNode.QualifiedName.NameSpace));
                            typeClassComplexMember.MemberAttributeCollection.Add(propertyAttribute);
                            break;
                    }

                    while (typeClassComplexMember.Name == typeClass.Name)
                        typeClassComplexMember.Name = typeClassComplexMember.Name + (++i);

                    typeClass.TypeMemberCollection.Add(typeClassComplexMember);
                }
            }
            return namespaceFixture;
        }
    }
}
