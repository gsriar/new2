﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using XPassThrough;

namespace X2JSON
{
    class JsonNodeParser
    {
        XMeta xMetaDataTree = null;
        XDocument xmldoc;

        public Node NodeParse(XDocument xmldoc)
        {
            this.xmldoc = xmldoc;
            prepareXtree();
            return NodeParse();
        }

        private void prepareXtree()
        {
            xMetaDataTree = XTreeBuilder.Instance.BuidXTree(xmldoc);
            CharacterCasingOption characterCasingOption = new CharacterCasingOption();
            characterCasingOption.CharCaseType = CharaterCaseType.None;
            characterCasingOption.SpecialCharCaseType = CharaterCaseType.None;
            xMetaDataTree.FormatQualifiedName(characterCasingOption);
        }

        private Node NodeParse()
        {
            Node node = PrepareJsonNode(xMetaDataTree.GetXDocument().Root as XElement);
            PrepareData(xMetaDataTree.GetXDocument().Root as XElement, node);
            return node;
        }

        public Node PrepareJsonNode(XElement xml, Node parent = null)
        {
            var xMetaNode = xMetaDataTree.NodeCollection.FirstOrDefault(x => x.QualifiedName.Name == xml.Name.LocalName && x.QualifiedName.NameSpace == xml.Name.Namespace);

            if (xMetaNode != null)
            {
                Node node = new Node() { Name = xMetaNode.QualifiedName.CustomName };

                List<XAttribute> xattributes = xml.Attributes().ToList();

                IEnumerable<XNode> xelelements = xml.Nodes().Where(n => n is XElement);

                foreach (var metaAttrib in xMetaNode.AttributeCollection)
                {
                    switch (metaAttrib.AttributeType)
                    {
                        case AttributeType.Attribute:

                            var attribute = xattributes.FirstOrDefault(f => metaAttrib.QualifiedName.ShallowSame(f.Name));

                            if (attribute != null && !string.IsNullOrEmpty(attribute.Value))
                                node.NameValueList.Add(new NameValue() { Name = "_" + metaAttrib.QualifiedName.CustomName, Value = attribute.Value });
                            break;
                        case AttributeType.Element:

                            XElement xe = xelelements.FirstOrDefault(e => metaAttrib.QualifiedName.ShallowSame((e as XElement).Name)) as XElement;

                            if (xe != null && !string.IsNullOrEmpty(xe.Value))
                                node.NameValueList.Add(new NameValue() { Name =   metaAttrib.QualifiedName.CustomName, Value = xe.Value });
                            break;
                    }
                }
                if (parent != null)
                {
                    parent.NodeList.Add(node);
                }
                return node;

            }
            return parent;
        }

        public void PrepareData(XElement xml, Node parentJsonNode = null)
        {
            foreach (XElement firstChild in xml.Nodes().Where(n => n is XElement))
            {
                var xMetaNode = xMetaDataTree.NodeCollection.FirstOrDefault(x => x.QualifiedName.Name == firstChild.Name.LocalName && x.QualifiedName.NameSpace == firstChild.Name.Namespace);

                if (xMetaNode != null)
                {
                    Node currentJsonNode = PrepareJsonNode(firstChild, parentJsonNode);
                    foreach (XElement childOfChild in firstChild.Nodes().Where(x => x is XElement))
                    {
                        Node cNode = PrepareJsonNode(childOfChild, currentJsonNode);
                        if (cNode != currentJsonNode)
                            PrepareData(childOfChild, cNode);

                    }
                }
            }
        }
    }
}
