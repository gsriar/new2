﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Newtonsoft.Json;

namespace X2JSON
{
    public class JsonWrite
    {
        private int indent = 0;
        private XDocument xmldoc = null;
        private TextWriter textWriter = null;
        private Pen pen;

        public void Init(XDocument xmldoc, TextWriter textWriter)
        {
            this.xmldoc = xmldoc;
            this.textWriter = textWriter;
            pen = new Pen(this.textWriter);
        }

        public void BuildJson(XDocument xml, TextWriter textWriter)
        {
                Init(xml, textWriter);
                PrepareJson();
            
        }


        private void PrepareJson()
        {
            JsonNodeParser xmltojson = new JsonNodeParser();
            Node node = xmltojson.NodeParse(xmldoc);

            string s = SharedHelper.SerializationHelper.Serialize<Node>(node);

            Pre(node.Name);
            Print(node.NameValueList, node.NodeList.Count > 0);

            Print(node);

            Post();
        }

        private void Print(Node node)
        {
            Print(node.NameValueList, node.NodeList.Count > 0);
            if (node.NameValueList.Count > 0)
                pen.WriteLine();
            Print(node.NodeList);
        }

        private void Print(List<NameValue> NameValue, bool lastComma = false)
        {
            int count = NameValue.Count;
            for (int n = 0; n < count; n++)
            {
                var vn = NameValue[n];

                pen.AppendIndented(indent, Constants.doubleQuote, vn.Name, Constants.doubleQuote, Constants.colon, Constants.space, Constants.doubleQuote, cleanForJSON(vn.Value), Constants.doubleQuote);

                if (n < count - 1)
                {
                    pen.Append(Constants.comma);
                    pen.WriteLine();
                }
                else
                {
                    if (lastComma)
                    {
                        pen.Append(Constants.comma);
                    }
                }
            }
        }

        public static string cleanForJSON(string s)
        {
            if (s == null || s.Length == 0)
            {
                return "";
            }

            char c = '\0';
            int i;
            int len = s.Length;
            StringBuilder sb = new StringBuilder(len + 4);
            String t;

            for (i = 0; i < len; i += 1)
            {
                c = s[i];
                switch (c)
                {
                    case '\\':
                    case '"':
                        sb.Append('\\');
                        sb.Append(c);
                        break;
                    case '/':
                        sb.Append('\\');
                        sb.Append(c);
                        break;
                    case '\b':
                        sb.Append("\\b");
                        break;
                    case '\t':
                        sb.Append("\\t");
                        break;
                    case '\n':
                        sb.Append("\\n");
                        break;
                    case '\f':
                        sb.Append("\\f");
                        break;
                    case '\r':
                        sb.Append("\\r");
                        break;
                    default:
                        if (c < ' ')
                        {
                            t = "000" + String.Format("X", c);
                            sb.Append("\\u" + t.Substring(t.Length - 4));
                        }
                        else
                        {
                            sb.Append(c);
                        }
                        break;
                }
            }
            return sb.ToString();
        }

        private void Print(NodeList node)
        {
            int count0 = node.SimilarListing.Count;
            for (int n0 = 0; n0 < count0; n0++)
            {
                var similar = node.SimilarListing[n0];

                BeginSimilar(similar);
                int count = similar.Nodes.Count;
                for (int n = 0; n < count; n++)
                {
                    var similarNode = similar.Nodes[n];
                    pen.AppendIndentedLine(indent, Constants.curlyOpen);
                    indent++;
                    Print(similarNode);

                    indent--;

                    pen.AppendIndentedLine(indent, Constants.curlyClose, n < count - 1 ? Constants.comma : "");
                }

                EndSimilar(similar, n0 < count0 - 1);
            }
        }

        #region
        private void BeginSimilar(Similar sim)
        {
            pen.AppendIndented(indent, Constants.doubleQuote, sim.Name, Constants.doubleQuote, Constants.colon, Constants.space);
            if (sim.Nodes.Count > 1)
            {
                pen.AppendWords(" ", Constants.squareOpen);
            }
            pen.WriteLine();
            indent++;
        }

        private void EndSimilar(Similar sim, bool appendComma)
        {
            indent--;
            if (sim.Nodes.Count > 1)
            {
                pen.AppendIndented(indent, Constants.squareClose);
                if (appendComma)
                    pen.Append(Constants.comma);
                pen.WriteLine();
            }
        }

        private void Pre(string Name)
        {
            pen.AppendIndentedLine(indent, Constants.curlyOpen);
            indent++;
            pen.AppendIndented(indent, Constants.doubleQuote, Name, Constants.doubleQuote, Constants.space, Constants.colon, Constants.space, Constants.curlyOpen);
            indent++;
            pen.WriteLine();
        }

        private void Post()
        {
            indent--;
            pen.AppendIndentedLine(indent, Constants.curlyClose);
            indent--;
            pen.AppendIndentedLine(indent, Constants.curlyClose);
        }
        #endregion
    }
}
