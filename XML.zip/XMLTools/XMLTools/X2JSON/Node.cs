﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;


namespace X2JSON
{
    [XmlRoot(ElementName = "node")]
    public class Node
    {
        public Node()
        {
            NameValueList = new List<NameValue>();
            NodeList = new NodeList();
        }
        [XmlAttribute(AttributeName = "name")]
        public string Name { get; set; }

        [XmlElement(ElementName = "namevaluelist")]
        public List<NameValue> NameValueList { get; set; }

        [XmlElement(ElementName = "childnodelist")]
        public NodeList NodeList { get; set; }

        [XmlAttribute(AttributeName = "group")]
        public bool Grouped { get; set; }
    }

    [XmlRoot(ElementName = "valuepair")]
    public class NameValue
    {
        [XmlAttribute(AttributeName = "name")]
        public string Name { get; set; }
        [XmlAttribute(AttributeName = "value")]
        public string Value { get; set; }
    }

    public class NodeList : List<Node>
    {
        [NonSerialized]
        public List<Similar> SimilarListing = new List<Similar>();

        public new void Add(Node node)
        {
            var last = SimilarListing.FirstOrDefault(f => f.Name == node.Name);
            node.Grouped = true;
            if (last != null)
            {
                last.Nodes.Add(node);
            }
            else
            {
                Similar similar = new Similar() { Name = node.Name };

                if (similar.Nodes == null)
                    similar.Nodes = new List<Node>();

                similar.Nodes.Add(node);
                SimilarListing.Add(similar);

            }
            base.Add(node);
        }

    }

    public class Similar
    {
        public string Name { get; set; }

        public List<Node> Nodes { get; set; }
    }
}

