﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace X2JSON
{
    class Constants
    {
        public const string curlyOpen = "{";

        public const string curlyClose = "}";

        public const string roundOpen = "(";

        public const string roundClose = ")";

        public const string squareOpen = "[";

        public const string squareClose = "]";

        public const string equalSign = "=";

        public const string semicolon = ";";

        public const string colon = ":";

        public const string doubleQuote = "\"";

        public const string comma = ",";

        public const string space = " ";
    }

    public class Pen
    {
        private TextWriter writeTip = null;

        public Pen(TextWriter pen)
        {
            this.writeTip = pen;
        }

        public void LeftIndent(int indent)
        {
            this.writeTip.Write(string.Empty.PadLeft(2*indent, ' '));
        }

        public void WriteIndentLine(int indent, params string[] words)
        {
            this.LeftIndent(indent);
            this.AppendWords(words);
            this.WriteLine();
        }

        public void WriteLine()
        {
            this.writeTip.WriteLine("");
        }

        public void WriteLine(string line)
        {
            this.writeTip.WriteLine(line);
        }

        public void Append(string text)
        {
            this.writeTip.Write(text);
        }

        public void WriteLines(int indent, params string[] text)
        {
            if (text != null)
            {
                for (int i = 0; i < text.Length; i++)
                {
                    string s = text[i];
                    this.WriteIndentLine(indent, new string[]
					{
						s
					});
                }
            }
        }


        public void WriteFormatedLine(int indent, string Format, params string[] args)
        {
            if (args != null)
            {
                this.LeftIndent(indent);
                this.writeTip.WriteLine(Format, args);
            }
        }


        public void AppendWords(params object[] text)
        {
            if (text != null)
            {
                for (int i = 0; i < text.Length; i++)
                {
                    object s = text[i];
                    this.writeTip.Write(s);
                    //this.writeTip.Write(' ');
                }
            }
        }

        public void AppendIndentFormated(int indent, string Format, params object[] args)
        {
            if (args != null)
            {
                this.LeftIndent(indent);
                this.writeTip.Write(Format, args);
            }
        }

        public void AppendIndentFormatedLine(int indent, string Format, params object[] args)
        {
            AppendIndentFormated(indent, Format, args);
            this.WriteLine();
        }

        public void AppendIndented(int indent, params object[] args)
        {
            if (args != null)
            {
                this.LeftIndent(indent);
                this.AppendWords(args);
            }
        }

        public void AppendIndentedLine(int indent, params object[] args)
        {
            AppendIndented(indent, args);
            this.WriteLine();
        }
    }
}
