﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RuleEngine.Data
{
    class Data
    {
        public Data(DataSchema.Entitity Entity)
        {

        }

        public DataSchema.Entitity Entity { get; private set; }


    }
}
