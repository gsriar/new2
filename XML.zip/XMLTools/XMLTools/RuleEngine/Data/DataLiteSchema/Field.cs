﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RuleEngine.Data.DataLiteSchema
{
    class Field
    {
        public string Name { get; set; }

        public bool IsKey { get; set; }

        public string DataType { get; set; }

        public int Length { get; set; }



    }
}
