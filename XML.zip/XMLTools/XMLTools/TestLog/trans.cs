﻿
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Xml2CS
{

    [XmlRoot(ElementName = "PurchaseOrder", Namespace = "http://www.adventure-works.com")]
    public class PurchaseOrder
    {

        [XmlAttribute(AttributeName = "PurchaseOrderNumber", Namespace = "http://www.adventure-works.com", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.Int32 PurchaseOrderNumber { get; set; }

        [XmlAttribute(AttributeName = "OrderDate", Namespace = "http://www.adventure-works.com", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String OrderDate { get; set; }

        [XmlAttribute(AttributeName = "xsi", Namespace = "http://www.w3.org/2000/xmlns/", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String xsi { get; set; }

        [XmlAttribute(AttributeName = "xsd", Namespace = "http://www.w3.org/2000/xmlns/", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String xsd { get; set; }

        [XmlAttribute(AttributeName = "aw", Namespace = "http://www.w3.org/2000/xmlns/", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String aw { get; set; }

        [XmlAttribute(AttributeName = "xmlns")]
        public System.String xmlns { get; set; }

        [XmlElement(ElementName = "Address", Namespace = "http://www.adventure-works.com")]
        public List<Address> Address { get; set; }

        [XmlText()]
        public string Text { get; set; }
    }

    [XmlRoot(ElementName = "Address", Namespace = "http://www.adventure-works.com")]
    public class Address
    {

        [XmlAttribute(AttributeName = "Type", Namespace = "http://www.adventure-works.com", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String Type { get; set; }

        [XmlElement(ElementName = "Name", Namespace = "http://www.adventure-works.com", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String Name { get; set; }

        [XmlElement(ElementName = "Street", Namespace = "http://www.adventure-works.com", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String Street { get; set; }

        [XmlElement(ElementName = "City", Namespace = "http://www.adventure-works.com", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String City { get; set; }

        [XmlElement(ElementName = "State", Namespace = "http://www.adventure-works.com", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String State { get; set; }

        [XmlElement(ElementName = "Zip", Namespace = "http://www.adventure-works.com", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String Zip { get; set; }

        [XmlElement(ElementName = "Country", Namespace = "http://www.adventure-works.com", Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public System.String Country { get; set; }

        [XmlText()]
        public string Text { get; set; }
    }
}