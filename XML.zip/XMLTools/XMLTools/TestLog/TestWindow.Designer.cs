﻿namespace TestLog
{
    partial class TestWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtXML = new System.Windows.Forms.TextBox();
            this.btnTransform = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.shift = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.chkOmit = new System.Windows.Forms.CheckBox();
            this.chkClean = new System.Windows.Forms.CheckBox();
            this.chkPK = new System.Windows.Forms.CheckBox();
            this.chkFK = new System.Windows.Forms.CheckBox();
            this.btnJson = new System.Windows.Forms.Button();
            this.btnHTML = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtXML
            // 
            this.txtXML.HideSelection = false;
            this.txtXML.Location = new System.Drawing.Point(12, 12);
            this.txtXML.Multiline = true;
            this.txtXML.Name = "txtXML";
            this.txtXML.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtXML.Size = new System.Drawing.Size(381, 383);
            this.txtXML.TabIndex = 0;
            this.txtXML.WordWrap = false;
            this.txtXML.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtXML_KeyDown);
            // 
            // btnTransform
            // 
            this.btnTransform.Location = new System.Drawing.Point(12, 480);
            this.btnTransform.Name = "btnTransform";
            this.btnTransform.Size = new System.Drawing.Size(75, 23);
            this.btnTransform.TabIndex = 1;
            this.btnTransform.Text = "xMeta";
            this.btnTransform.UseVisualStyleBackColor = true;
            this.btnTransform.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtResult
            // 
            this.txtResult.HideSelection = false;
            this.txtResult.Location = new System.Drawing.Point(444, 12);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResult.Size = new System.Drawing.Size(699, 383);
            this.txtResult.TabIndex = 2;
            this.txtResult.WordWrap = false;
            // 
            // shift
            // 
            this.shift.AutoSize = true;
            this.shift.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shift.Location = new System.Drawing.Point(399, 157);
            this.shift.Name = "shift";
            this.shift.Size = new System.Drawing.Size(29, 20);
            this.shift.TabIndex = 3;
            this.shift.Text = ">>";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(353, 480);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "XMl2CS";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(237, 480);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "XML2SQL";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(141, 480);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // chkOmit
            // 
            this.chkOmit.AutoSize = true;
            this.chkOmit.Location = new System.Drawing.Point(94, 417);
            this.chkOmit.Name = "chkOmit";
            this.chkOmit.Size = new System.Drawing.Size(131, 17);
            this.chkOmit.TabIndex = 7;
            this.chkOmit.Text = "Omit Values Collection";
            this.chkOmit.UseVisualStyleBackColor = true;
            // 
            // chkClean
            // 
            this.chkClean.AutoSize = true;
            this.chkClean.Location = new System.Drawing.Point(94, 437);
            this.chkClean.Name = "chkClean";
            this.chkClean.Size = new System.Drawing.Size(90, 17);
            this.chkClean.TabIndex = 8;
            this.chkClean.Text = "Cleanup XML";
            this.chkClean.UseVisualStyleBackColor = true;
            // 
            // chkPK
            // 
            this.chkPK.AutoSize = true;
            this.chkPK.Location = new System.Drawing.Point(280, 417);
            this.chkPK.Name = "chkPK";
            this.chkPK.Size = new System.Drawing.Size(128, 17);
            this.chkPK.TabIndex = 9;
            this.chkPK.Text = "Generate Primary Key";
            this.chkPK.UseVisualStyleBackColor = true;
            // 
            // chkFK
            // 
            this.chkFK.AutoSize = true;
            this.chkFK.Location = new System.Drawing.Point(280, 437);
            this.chkFK.Name = "chkFK";
            this.chkFK.Size = new System.Drawing.Size(129, 17);
            this.chkFK.TabIndex = 10;
            this.chkFK.Text = "Generate Foreign Key";
            this.chkFK.UseVisualStyleBackColor = true;
            // 
            // btnJson
            // 
            this.btnJson.Location = new System.Drawing.Point(460, 480);
            this.btnJson.Name = "btnJson";
            this.btnJson.Size = new System.Drawing.Size(75, 23);
            this.btnJson.TabIndex = 11;
            this.btnJson.Text = "XML2JSON";
            this.btnJson.UseVisualStyleBackColor = true;
            this.btnJson.Click += new System.EventHandler(this.btnJson_Click);
            // 
            // btnHTML
            // 
            this.btnHTML.Location = new System.Drawing.Point(559, 480);
            this.btnHTML.Name = "btnHTML";
            this.btnHTML.Size = new System.Drawing.Size(75, 23);
            this.btnHTML.TabIndex = 12;
            this.btnHTML.Text = "XML2HTML";
            this.btnHTML.UseVisualStyleBackColor = true;
            this.btnHTML.Click += new System.EventHandler(this.btnHTML_Click);
            // 
            // TestWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1155, 543);
            this.Controls.Add(this.btnHTML);
            this.Controls.Add(this.btnJson);
            this.Controls.Add(this.chkFK);
            this.Controls.Add(this.chkPK);
            this.Controls.Add(this.chkClean);
            this.Controls.Add(this.chkOmit);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.shift);
            this.Controls.Add(this.txtResult);
            this.Controls.Add(this.btnTransform);
            this.Controls.Add(this.txtXML);
            this.Name = "TestWindow";
            this.Text = "Test Window";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtXML;
        private System.Windows.Forms.Button btnTransform;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label shift;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.CheckBox chkOmit;
        private System.Windows.Forms.CheckBox chkClean;
        private System.Windows.Forms.CheckBox chkPK;
        private System.Windows.Forms.CheckBox chkFK;
        private System.Windows.Forms.Button btnJson;
        private System.Windows.Forms.Button btnHTML;
    }
}

