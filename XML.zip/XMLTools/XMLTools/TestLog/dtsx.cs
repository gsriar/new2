﻿using System;
using System.Collections.Generic;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace Xml2CS
{
    [XmlRoot(ElementName = "Executable", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class Executable
    {
        [XmlAttribute(AttributeName = "DTS", Namespace = "http://www.w3.org/2000/xmlns/", Form = XmlSchemaForm.Qualified)]
        public System.String DTS { get; set; }

        [XmlAttribute(AttributeName = "ExecutableType", Form = XmlSchemaForm.Qualified)]
        public System.String ExecutableType { get; set; }

        [XmlAttribute(AttributeName = "ThreadHint", Form = XmlSchemaForm.Qualified)]
        public System.Byte ThreadHint { get; set; }

        [XmlAttribute(AttributeName = "IDREF")]
        public System.String IDREF { get; set; }

        [XmlAttribute(AttributeName = "IsFrom", Form = XmlSchemaForm.Qualified)]
        public System.Int32 IsFrom { get; set; }

        [XmlElement(ElementName = "Property", Form = XmlSchemaForm.Qualified)]
        public List<Property> Property { get; set; }

        [XmlElement(ElementName = "ConnectionManager", Form = XmlSchemaForm.Qualified)]
        public List<ConnectionManager> ConnectionManager { get; set; }

        [XmlElement(ElementName = "PackageVariable", Form = XmlSchemaForm.Qualified)]
        public List<PackageVariable> PackageVariable { get; set; }

        [XmlElement(ElementName = "Variable", Form = XmlSchemaForm.Qualified)]
        public Variable Variable { get; set; }

        [XmlElement(ElementName = "LoggingOptions", Form = XmlSchemaForm.Qualified)]
        public LoggingOptions LoggingOptions { get; set; }

        [XmlElement(ElementName = "Executable", Form = XmlSchemaForm.Qualified)]
        public List<Executable> Executable1 { get; set; }

        [XmlElement(ElementName = "PrecedenceConstraint", Form = XmlSchemaForm.Qualified)]
        public PrecedenceConstraint PrecedenceConstraint { get; set; }

        [XmlElement(ElementName = "ObjectData", Form = XmlSchemaForm.Qualified)]
        public ObjectData ObjectData { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "Property", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class Property
    {
        [XmlAttribute(AttributeName = "Name", Form = XmlSchemaForm.Qualified)]
        public System.String Name { get; set; }

        [XmlAttribute(AttributeName = "DataType", Form = XmlSchemaForm.Qualified)]
        public System.Byte DataType { get; set; }

        [XmlAttribute(AttributeName = "space", Namespace = "http://www.w3.org/XML/1998/namespace", Form = XmlSchemaForm.Qualified)]
        public System.String space { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "ConnectionManager", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class ConnectionManager
    {
        [XmlElement(ElementName = "Property", Form = XmlSchemaForm.Qualified)]
        public List<Property> Property { get; set; }

        [XmlElement(ElementName = "ObjectData", Form = XmlSchemaForm.Qualified)]
        public ObjectData ObjectData { get; set; }

        [XmlElement(ElementName = "FlatFileColumn", Form = XmlSchemaForm.Qualified)]
        public List<FlatFileColumn> FlatFileColumn { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "ObjectData", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class ObjectData
    {
        [XmlElement(ElementName = "ConnectionManager", Form = XmlSchemaForm.Qualified)]
        public ConnectionManager ConnectionManager { get; set; }

        [XmlElement(ElementName = "SqlTaskData", Namespace = "www.microsoft.com/sqlserver/dts/tasks/sqltask", Form = XmlSchemaForm.Qualified)]
        public SqlTaskData SqlTaskData { get; set; }

        [XmlElement(ElementName = "pipeline")]
        public pipeline pipeline { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "FlatFileColumn", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class FlatFileColumn
    {
        [XmlElement(ElementName = "Property", Form = XmlSchemaForm.Qualified)]
        public List<Property> Property { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "PackageVariable", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class PackageVariable
    {
        [XmlElement(ElementName = "Property", Form = XmlSchemaForm.Qualified)]
        public List<Property> Property { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "Variable", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class Variable
    {
        [XmlElement(ElementName = "Property", Form = XmlSchemaForm.Qualified)]
        public List<Property> Property { get; set; }

        [XmlElement(ElementName = "VariableValue", Form = XmlSchemaForm.Qualified)]
        public VariableValue VariableValue { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "VariableValue", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class VariableValue
    {
        [XmlAttribute(AttributeName = "DataType", Form = XmlSchemaForm.Qualified)]
        public System.Byte DataType { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "LoggingOptions", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class LoggingOptions
    {
        [XmlElement(ElementName = "Property", Form = XmlSchemaForm.Qualified)]
        public List<Property> Property { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "SqlTaskData", Namespace = "www.microsoft.com/sqlserver/dts/tasks/sqltask")]
    [Serializable]
    public class SqlTaskData
    {
        [XmlAttribute(AttributeName = "Connection", Form = XmlSchemaForm.Qualified)]
        public System.String Connection { get; set; }

        [XmlAttribute(AttributeName = "TimeOut", Form = XmlSchemaForm.Qualified)]
        public System.Byte TimeOut { get; set; }

        [XmlAttribute(AttributeName = "IsStoredProc", Form = XmlSchemaForm.Qualified)]
        public System.String IsStoredProc { get; set; }

        [XmlAttribute(AttributeName = "SqlStmtSourceType", Form = XmlSchemaForm.Qualified)]
        public System.String SqlStmtSourceType { get; set; }

        [XmlAttribute(AttributeName = "SqlStatementSource", Form = XmlSchemaForm.Qualified)]
        public System.String SqlStatementSource { get; set; }

        [XmlAttribute(AttributeName = "ResultType", Form = XmlSchemaForm.Qualified)]
        public System.String ResultType { get; set; }

        [XmlAttribute(AttributeName = "SQLTask", Namespace = "http://www.w3.org/2000/xmlns/", Form = XmlSchemaForm.Qualified)]
        public System.String SQLTask { get; set; }

    }

    [XmlRoot(ElementName = "pipeline")]
    [Serializable]
    public class pipeline
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Byte id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "defaultBufferMaxRows")]
        public System.Byte defaultBufferMaxRows { get; set; }

        [XmlAttribute(AttributeName = "engineThreads")]
        public System.Byte engineThreads { get; set; }

        [XmlAttribute(AttributeName = "defaultBufferSize")]
        public System.Int32 defaultBufferSize { get; set; }

        [XmlAttribute(AttributeName = "BLOBTempStoragePath")]
        public System.String BLOBTempStoragePath { get; set; }

        [XmlAttribute(AttributeName = "bufferTempStoragePath")]
        public System.String bufferTempStoragePath { get; set; }

        [XmlAttribute(AttributeName = "runInOptimizedMode")]
        public System.String runInOptimizedMode { get; set; }

        [XmlElement(ElementName = "components")]
        public components components { get; set; }

        [XmlElement(ElementName = "paths")]
        public paths paths { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "components")]
    [Serializable]
    public class components
    {
        [XmlElement(ElementName = "component")]
        public List<component> component { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "component")]
    [Serializable]
    public class component
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Int32 id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "componentClassID")]
        public System.String componentClassID { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "localeId")]
        public System.Int32 localeId { get; set; }

        [XmlAttribute(AttributeName = "usesDispositions")]
        public System.String usesDispositions { get; set; }

        [XmlAttribute(AttributeName = "validateExternalMetadata")]
        public System.String validateExternalMetadata { get; set; }

        [XmlAttribute(AttributeName = "version")]
        public System.Byte version { get; set; }

        [XmlAttribute(AttributeName = "pipelineVersion")]
        public System.Byte pipelineVersion { get; set; }

        [XmlAttribute(AttributeName = "contactInfo")]
        public System.String contactInfo { get; set; }

        [XmlElement(ElementName = "properties")]
        public properties properties { get; set; }

        [XmlElement(ElementName = "connections")]
        public connections connections { get; set; }

        [XmlElement(ElementName = "outputs")]
        public outputs outputs { get; set; }

        [XmlElement(ElementName = "inputs")]
        public inputs inputs { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "properties")]
    [Serializable]
    public class properties
    {
        [XmlElement(ElementName = "property")]
        public List<property> property { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "property")]
    [Serializable]
    public class property
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Int32 id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "dataType")]
        public System.String dataType { get; set; }

        [XmlAttribute(AttributeName = "state")]
        public System.String state { get; set; }

        [XmlAttribute(AttributeName = "isArray")]
        public System.String isArray { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "typeConverter")]
        public System.String typeConverter { get; set; }

        [XmlAttribute(AttributeName = "UITypeEditor")]
        public System.String UITypeEditor { get; set; }

        [XmlAttribute(AttributeName = "containsID")]
        public System.String containsID { get; set; }

        [XmlAttribute(AttributeName = "expressionType")]
        public System.String expressionType { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "connections")]
    [Serializable]
    public class connections
    {
        [XmlElement(ElementName = "connection")]
        public connection connection { get; set; }

    }

    [XmlRoot(ElementName = "connection")]
    [Serializable]
    public class connection
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Int32 id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "connectionManagerID")]
        public System.String connectionManagerID { get; set; }

    }

    [XmlRoot(ElementName = "outputs")]
    [Serializable]
    public class outputs
    {
        [XmlElement(ElementName = "output")]
        public List<output> output { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "output")]
    [Serializable]
    public class output
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Int32 id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "exclusionGroup")]
        public System.Byte exclusionGroup { get; set; }

        [XmlAttribute(AttributeName = "synchronousInputId")]
        public System.Int32 synchronousInputId { get; set; }

        [XmlAttribute(AttributeName = "deleteOutputOnPathDetached")]
        public System.String deleteOutputOnPathDetached { get; set; }

        [XmlAttribute(AttributeName = "hasSideEffects")]
        public System.String hasSideEffects { get; set; }

        [XmlAttribute(AttributeName = "dangling")]
        public System.String dangling { get; set; }

        [XmlAttribute(AttributeName = "isErrorOut")]
        public System.String isErrorOut { get; set; }

        [XmlAttribute(AttributeName = "isSorted")]
        public System.String isSorted { get; set; }

        [XmlAttribute(AttributeName = "errorOrTruncationOperation")]
        public System.String errorOrTruncationOperation { get; set; }

        [XmlAttribute(AttributeName = "errorRowDisposition")]
        public System.String errorRowDisposition { get; set; }

        [XmlAttribute(AttributeName = "truncationRowDisposition")]
        public System.String truncationRowDisposition { get; set; }

        [XmlElement(ElementName = "outputColumns")]
        public outputColumns outputColumns { get; set; }

        [XmlElement(ElementName = "externalMetadataColumns")]
        public externalMetadataColumns externalMetadataColumns { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "outputColumns")]
    [Serializable]
    public class outputColumns
    {
        [XmlElement(ElementName = "outputColumn")]
        public List<outputColumn> outputColumn { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "outputColumn")]
    [Serializable]
    public class outputColumn
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Int32 id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "lineageId")]
        public System.Int32 lineageId { get; set; }

        [XmlAttribute(AttributeName = "precision")]
        public System.Byte precision { get; set; }

        [XmlAttribute(AttributeName = "scale")]
        public System.Byte scale { get; set; }

        [XmlAttribute(AttributeName = "length")]
        public System.Int32 length { get; set; }

        [XmlAttribute(AttributeName = "dataType")]
        public System.String dataType { get; set; }

        [XmlAttribute(AttributeName = "codePage")]
        public System.Int32 codePage { get; set; }

        [XmlAttribute(AttributeName = "sortKeyPosition")]
        public System.Byte sortKeyPosition { get; set; }

        [XmlAttribute(AttributeName = "comparisonFlags")]
        public System.Byte comparisonFlags { get; set; }

        [XmlAttribute(AttributeName = "specialFlags")]
        public System.Byte specialFlags { get; set; }

        [XmlAttribute(AttributeName = "errorOrTruncationOperation")]
        public System.String errorOrTruncationOperation { get; set; }

        [XmlAttribute(AttributeName = "errorRowDisposition")]
        public System.String errorRowDisposition { get; set; }

        [XmlAttribute(AttributeName = "truncationRowDisposition")]
        public System.String truncationRowDisposition { get; set; }

        [XmlAttribute(AttributeName = "externalMetadataColumnId")]
        public System.Int32 externalMetadataColumnId { get; set; }

        [XmlElement(ElementName = "properties")]
        public properties properties { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

    [XmlRoot(ElementName = "externalMetadataColumns")]
    [Serializable]
    public class externalMetadataColumns
    {
        [XmlAttribute(AttributeName = "isUsed")]
        public System.String isUsed { get; set; }

        [XmlElement(ElementName = "externalMetadataColumn")]
        public List<externalMetadataColumn> externalMetadataColumn { get; set; }

    }

    [XmlRoot(ElementName = "externalMetadataColumn")]
    [Serializable]
    public class externalMetadataColumn
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Int32 id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "precision")]
        public System.Byte precision { get; set; }

        [XmlAttribute(AttributeName = "scale")]
        public System.Byte scale { get; set; }

        [XmlAttribute(AttributeName = "length")]
        public System.Int32 length { get; set; }

        [XmlAttribute(AttributeName = "dataType")]
        public System.String dataType { get; set; }

        [XmlAttribute(AttributeName = "codePage")]
        public System.Byte codePage { get; set; }

    }

    [XmlRoot(ElementName = "inputs")]
    [Serializable]
    public class inputs
    {
        [XmlElement(ElementName = "input")]
        public input input { get; set; }

    }

    [XmlRoot(ElementName = "input")]
    [Serializable]
    public class input
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Int32 id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "hasSideEffects")]
        public System.String hasSideEffects { get; set; }

        [XmlAttribute(AttributeName = "dangling")]
        public System.String dangling { get; set; }

        [XmlAttribute(AttributeName = "errorOrTruncationOperation")]
        public System.String errorOrTruncationOperation { get; set; }

        [XmlAttribute(AttributeName = "errorRowDisposition")]
        public System.String errorRowDisposition { get; set; }

        [XmlAttribute(AttributeName = "truncationRowDisposition")]
        public System.String truncationRowDisposition { get; set; }

        [XmlElement(ElementName = "externalMetadataColumns")]
        public externalMetadataColumns externalMetadataColumns { get; set; }

        [XmlElement(ElementName = "inputColumns")]
        public inputColumns inputColumns { get; set; }

    }

    [XmlRoot(ElementName = "inputColumns")]
    [Serializable]
    public class inputColumns
    {
        [XmlElement(ElementName = "inputColumn")]
        public List<inputColumn> inputColumn { get; set; }

    }

    [XmlRoot(ElementName = "inputColumn")]
    [Serializable]
    public class inputColumn
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Int32 id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "lineageId")]
        public System.Int32 lineageId { get; set; }

        [XmlAttribute(AttributeName = "usageType")]
        public System.String usageType { get; set; }

        [XmlAttribute(AttributeName = "errorOrTruncationOperation")]
        public System.String errorOrTruncationOperation { get; set; }

        [XmlAttribute(AttributeName = "errorRowDisposition")]
        public System.String errorRowDisposition { get; set; }

        [XmlAttribute(AttributeName = "truncationRowDisposition")]
        public System.String truncationRowDisposition { get; set; }

        [XmlAttribute(AttributeName = "externalMetadataColumnId")]
        public System.Int32 externalMetadataColumnId { get; set; }

    }

    [XmlRoot(ElementName = "paths")]
    [Serializable]
    public class paths
    {
        [XmlElement(ElementName = "path")]
        public List<path> path { get; set; }

    }

    [XmlRoot(ElementName = "path")]
    [Serializable]
    public class path
    {
        [XmlAttribute(AttributeName = "id")]
        public System.Int32 id { get; set; }

        [XmlAttribute(AttributeName = "name")]
        public System.String name { get; set; }

        [XmlAttribute(AttributeName = "description")]
        public System.String description { get; set; }

        [XmlAttribute(AttributeName = "startId")]
        public System.Int32 startId { get; set; }

        [XmlAttribute(AttributeName = "endId")]
        public System.Int32 endId { get; set; }

    }

    [XmlRoot(ElementName = "PrecedenceConstraint", Namespace = "www.microsoft.com/SqlServer/Dts")]
    [Serializable]
    public class PrecedenceConstraint
    {
        [XmlElement(ElementName = "Property", Form = XmlSchemaForm.Qualified)]
        public List<Property> Property { get; set; }

        [XmlElement(ElementName = "Executable", Form = XmlSchemaForm.Qualified)]
        public List<Executable> Executable { get; set; }

        [XmlText]
        public string Text { get; set; }

    }

}
