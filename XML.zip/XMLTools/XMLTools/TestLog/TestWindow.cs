﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;
using X2SQL;
using XPassThrough;

namespace TestLog
{
    public partial class TestWindow : Form
    {
        string xmlPath = @"C:\Users\gs374\Downloads\KnowledgeBuilder\XMLTools\TestLog\dtsx.xml";//@"G:\EDU\KnowledgeBuilder\XMLTools\TestLog\dtsx.xml";
        public TestWindow()
        {
            InitializeComponent();
            txtXML.Text = File.ReadAllText(xmlPath);
            txtResult.KeyDown += txtXML_KeyDown;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clear();
            XMl2XTree();
        }

        void XMl2CSh()
        {
            string xml = txtXML.Text;
            string result = null;
            try
            {
                using (var sr = new StringReader(xml))
                {
                    XDocument doc = XDocument.Load(sr);
                }
            }
            catch (Exception ex)
            {
                result = ex.Message + Environment.NewLine + ex.StackTrace;
            }
            txtResult.Text = result;
        }

        void XMl2XTree()
        {
            clear();
            string xmltxt = txtXML.Text;

            using (var sr = new StringReader(xmltxt))
            {
                CharacterCasingOption option = new CharacterCasingOption() { CharCaseType = CharaterCaseType.Pascal };
                XDocument xmldoc = XDocument.Load(sr);
                XMeta xMeta = XTreeBuilder.Instance.BuidXTree(xmldoc);

                if (chkClean.Checked)
                    xMeta.CleanXtree();

                xMeta.FormatQualifiedName(option);

                if (chkOmit.Checked)
                {
                    foreach (var n in xMeta.NodeCollection)
                    {
                        //n.InnerTextCollection = null;
                        foreach (var a in n.AttributeCollection)
                            a.AttributeValueCollection = null;
                    }

                }
                txtResult.Text = SharedHelper.SerializationHelper.Serialize<XMeta>(xMeta);
            }
        }

        void XMl2XTreeHirerechy()
        {
            clear();
            string xmltxt = txtXML.Text;

            using (var sr = new StringReader(xmltxt))
            {
                StringBuilder sb = new StringBuilder();
                CharacterCasingOption option = new CharacterCasingOption() { CharCaseType = CharaterCaseType.Pascal };
                XDocument xmldoc = XDocument.Load(sr);
                XMeta xMeta = XTreeBuilder.Instance.BuidXTree(xmldoc);
                xMeta.CleanAndApplyQualifiedName(option);

                foreach (var n in xMeta.NodeCollection)
                {
                    sb.Append(n.QualifiedName.CustomName + "[" + xMeta.NodeCollection.IndexOf(n) + "]");
                    sb.AppendLine();

                    foreach (var cn in n.ChidCollection)
                    {
                        var ccn = xMeta.NodeCollection.Find(a => a.QualifiedName.ShallowSame(cn.QualifiedName));
                        sb.Append('\t');
                        sb.Append(cn.QualifiedName.CustomName + "[" + xMeta.NodeCollection.IndexOf(ccn) + "]");
                        sb.AppendLine();
                    }
                }
                txtResult.Text = sb.ToString();
            }
        }

        void XMl2CS()
        {
            clear();
            string xmltxt = txtXML.Text;
            string result = null;
            try
            {
                using (var sr = new StringReader(xmltxt))
                {
                    CharacterCasingOption option = new CharacterCasingOption() { CharCaseType = CharaterCaseType.Pascal };
                    XDocument xmldoc = XDocument.Load(sr);
                    X2CS.XML2CS xml2cs = new X2CS.XML2CS(xmldoc);
                    string file = "gopi.cs";
                    if (File.Exists(file))
                        File.Delete(file);
                    using (StreamWriter sw = File.CreateText(file))
                    {
                        xml2cs.Print(xmldoc, sw, option, X2CS.Shared.OutputTypeEnum.Serializable);
                    }
                    result = File.ReadAllText(file);
                }
            }
            catch (Exception ex)
            {
                result = ex.Message + Environment.NewLine + ex.StackTrace;
            }
            txtResult.Text = result;
        }


        private void txtXML_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && (e.KeyCode == Keys.A))
            {
                if (sender != null)
                    ((TextBox)sender).SelectAll();
                e.Handled = true;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            clear();
            XMl2CS();
        }

        public void SerialTest()
        {
            try
            {
                var po = Helper.Deserialize<Xml2CS.Executable>(xmlPath);

                Helper.Serialize<Xml2CS.Executable>(po, xmlPath + "re.xml");
            }
            catch (Exception ex)
            {
                txtXML.Text = ex.Message;
            }
        }

        public void XML2SQL()
        {

            clear();
            string xmltxt = txtXML.Text;
            try
            {
                using (var sr = new StringReader(xmltxt))
                {
                    XDocument xmldoc = XDocument.Load(sr);
                    CharacterCasingOption option = new CharacterCasingOption() { CharCaseType = CharaterCaseType.Pascal };
                    TransformationOption transformationOptions = new TransformationOption();
                    transformationOptions.DefinitionOption.PrimaryKeyOptions.AutoGeneratePrimaryKey = chkPK.Checked;
                    transformationOptions.DefinitionOption.ForeignKeyOptions.GenerateReferenceForeignKeys = chkFK.Checked;
                    transformationOptions.CharacterCasingOption = option;
                    txtResult.Text = X2SQL.X2SQL.Instance.BuildSQL(xmldoc, transformationOptions);
                }
            }
            catch (Exception ex)
            {
                txtResult.Text = ex.Message;
            }

        }


        private void button2_Click(object sender, EventArgs e)
        {
            clear();
            XML2SQL();
        }
        void clear()
        {
            txtResult.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            XMl2XTreeHirerechy();
        }

        private void btnJson_Click(object sender, EventArgs e)
        {
            clear();
            string xmltxt = txtXML.Text;
            try
            {
                using (var sr = new StringReader(xmltxt))
                {
                    XDocument xmldoc = XDocument.Load(sr);
                    X2JSON.JsonWrite writer = new X2JSON.JsonWrite();

                    StringBuilder sb = new StringBuilder();
                    using (TextWriter textWriter = new StringWriter(sb))
                    {
                        writer.BuildJson(xmldoc, textWriter); ;
                    }
                    txtResult.Text = sb.ToString();
                }
            }
            catch (Exception ex)
            {
                txtResult.Text = ex.Message;
            }
        }

        private void btnHTML_Click(object sender, EventArgs e)
        {
            clear();
            string xmltxt = txtXML.Text;
            try
            {
                using (var sr = new StringReader(xmltxt))
                {
                    XDocument xmldoc = XDocument.Load(sr);
                    
                     StringBuilder sb = new StringBuilder();
                     using (TextWriter textWriter = new StringWriter(sb))
                     {
                         X2HTML.X2H writer = new X2HTML.X2H(@"C:\Users\gs374\Downloads\KnowledgeBuilder\XMLTools\XWeb\Content", xmldoc, textWriter);
                         writer.HTMLParse(); ;
                     }

                     txtResult.Text = sb.ToString();
                }
            }
            catch (Exception ex)
            {
                txtResult.Text = ex.Message;
            }
        }
    }
}
