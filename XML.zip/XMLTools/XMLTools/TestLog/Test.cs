﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestLog
{
    public partial class Test : Form
    {
        public Test()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var dtb = GetTable();
        }
        /// <summary>
        /// Generates a DataTable with four columns.
        /// </summary>
        static DataTable GetTable()
        {
            //
            // Here we create a DataTable and add columns to it.
            //
            DataTable table = new DataTable();
            table.Columns.Add("Dosage", typeof(int));
            table.Columns.Add("Medication", typeof(string));
            table.Columns.Add("Patient", typeof(string));
            //
            // Add another column to the data table in a different way.
            //
            DataColumn column = new DataColumn("Appointment", typeof(DateTime));
            table.Columns.Add(column);
            //
            // Here we add some DataRows.
            // Note that the row parameters must match the order and types of the columns.
            //
            table.Rows.Add(21, "Combivent", "Janet", DateTime.Now);
            table.Rows.Add(100, "Dilantin", "Melanie", DateTime.Now);
            return table;
        }
    }
}
