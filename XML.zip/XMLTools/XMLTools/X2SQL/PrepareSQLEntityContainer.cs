﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using XPassThrough;

namespace X2SQL.Prepare
{
    public class SQLEntityParser
    {
        public XMeta xMeta;
        private int i = 0;
        private SQLEntityContainer sqlEntityContainer = null;

        public SQLEntityContainer Parse(XMeta xMeta, TransformationOption transformationOption)
        {
            this.xMeta = xMeta;
            sqlEntityContainer = new SQLEntityContainer();

            DefinationOption options = transformationOption.DefinitionOption;
            foreach (Node node in xMeta.NodeCollection)
            {
                PrepareNodeTable(node, options);
            }

            if (transformationOption.DefinitionOption.ForeignKeyOptions.GenerateReferenceForeignKeys)
            {
                PrepareRelations();
            }

            //List<Table> tableListWithNoColu = new List<Table>();

            //for (int i = 0; i < sqlEntityContainer.Tables.Count; i++)
            //{
            //    var table = sqlEntityContainer.Tables[i] as Table;

            //    if (table.Columns.Count() == 0)
            //    {
            //        tableList.Add(table);                  
            //    }
            //}

            //foreach (var t in tableList)
            //{
            //    sqlEntityContainer.Tables.Remove(t);
            //}
         
            return sqlEntityContainer;
        }


        public Table PrepareNodeTable(Node node, DefinationOption options)
        {
            Table table = options.PrimaryKeyOptions.AutoGeneratePrimaryKey ? new Table(node.QualifiedName.Name, true) : new Table(node.QualifiedName.Name);
            table.Name = node.QualifiedName.CustomName;
            if (options.PrimaryKeyOptions.AutoGeneratePrimaryKey)
            {
                string name = options.PrimaryKeyOptions.PrimaryKeyName;
                if (options.PrimaryKeyOptions.PrefixTableName)
                    name = table.Name + name;

                Column pkColumn = null;

                if (options.PrimaryKeyOptions.AutoGenratedPrimaryKeyType == AutoGenratedPrimaryKeyType.Identity)
                    pkColumn = new Column(name, true, true) { DataTypeName = SQLTypeHelper.Resolve(typeof(int)), AllowDBNull = false, MaxLength = -1, AutoIncrement = true };
                else
                    pkColumn = new Column(name, true, true) { DataTypeName = SQLTypeHelper.Resolve(typeof(Guid)), AllowDBNull = false, MaxLength = -1 };

                table.AddColumn(pkColumn);
                table.PrimaryKeyConstraint = new PrimaryKeyConstraint("PK_" + table.Name);
                table.PrimaryKeyConstraint.Table = table;
                table.PrimaryKeyConstraint.Columns.Add(pkColumn);
            }

            foreach (XPassThrough.Attribute att in node.AttributeCollection)
            {
                SharedHelper.DataInfoResolve.DataInfo dataInfo = SharedHelper.DataInfoResolve.Resolve(att.AttributeValueCollection);
                Column column = new Column(att.QualifiedName.Name) { DataTypeName = SQLTypeHelper.Resolve(dataInfo.Type), AllowDBNull = true, MaxLength = dataInfo.MaxLength };
                column.Name = att.QualifiedName.CustomName;
                if (table[column.Name] == null)
                    table.AddColumn(column);
            }

            //if (node.InnerTextCollection.Count > 0)
            //{
            //    Column column = new Column(Constant.InnerText) { DataTypeName = SQLTypeHelper.Resolve(typeof(string)), AllowDBNull = true, MaxLength = 4000 };
            //    column.Name = Constant.InnerText;
            //    table.AddColumn(column);
            //}

            sqlEntityContainer.Tables.Add(table);

            return table;
        }

        private void PrepareRelations()
        {
            foreach (Node primaryNode in xMeta.NodeCollection)
            {
                Table primaryTable = sqlEntityContainer.Tables.Find(t => t.Name == primaryNode.QualifiedName.CustomName);

                foreach (var childNodeRef in primaryNode.ChidCollection)
                {
                    Node childNode = xMeta.NodeCollection.First(f => f.QualifiedName.ShallowSame(childNodeRef.QualifiedName));
                    Table childTable = sqlEntityContainer.Tables.Find(t => t.Name == childNode.QualifiedName.CustomName);
                    AddPrimaryKeyForignKeyRelation(primaryTable, childTable);
                }
            }
        }

        public void AddPrimaryKeyForignKeyRelation(Table primaryTable, Table childTable)
        {
            if (primaryTable.PrimaryKeyConstraint != null)
            {
                var check = sqlEntityContainer.TableLevelConstraints.FindAll(c => c is ForeignKeyConstraint).
                    FindAll(c =>
                    {
                        var fk = c as ForeignKeyConstraint;
                        return fk.ChildTable == childTable && fk.PrimaryTable == primaryTable;
                    });

                if (check.Count == 0)
                {
                    var childColumns = GetMatchColumns(childTable, primaryTable.PrimaryKeyConstraint.Columns, true);
                    ForeignKeyConstraint fkey = new ForeignKeyConstraint(string.Format("FK_{0}_{1}_{2:D2}", childTable.Name, primaryTable.Name, i++));
                    fkey.ChildTable = childTable;
                    fkey.PrimaryTable = primaryTable;
                    fkey.ChildColumns.AddRange(childColumns);
                    fkey.PrimaryColumns.AddRange(primaryTable.PrimaryKeyConstraint.Columns);

                    sqlEntityContainer.TableLevelConstraints.Add(fkey);
                }
            }
        }


        public List<Column> GetMatchColumns(Table childTable, IEnumerable<Column> primaryColumns, bool generateIfNotExists)
        {
            List<Column> resultList = new List<Column>(primaryColumns.Count());
            foreach (Column col in primaryColumns)
            {
                var childMatchingCol = childTable.Columns.FirstOrDefault(c => c.Name == col.Name && c.DataTypeName == col.DataTypeName);

                if (childMatchingCol == null || (childMatchingCol!=null && childMatchingCol.Table==col.Table))
                {
                    if (generateIfNotExists)
                    {
                        Column newCol = new Column(col.Name);
                        col.ShallowCopyTo(newCol);

                        int i = 1;
                        while (childTable[newCol.Name] != null)
                            newCol.Name = newCol.Name + i;

                        newCol.AllowDBNull = true;
                        childTable.AddColumn(newCol);
                        resultList.Add(newCol);
                    }
                }
                else
                {
                    resultList.Add(childMatchingCol);
                }
            }

            return resultList;
        }
    }
}
