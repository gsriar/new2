using System;
namespace X2SQL
{
	public abstract class ColumnLevelConstraint : SQLEntity
	{
		public ColumnLevelConstraintType ColumnLevelConstraintType
		{
			get;
			set;
		}
		public ColumnLevelConstraint(ColumnLevelConstraintType type, string name) : base(SQLEntityType.Constraint, name)
		{
			this.ColumnLevelConstraintType = this.ColumnLevelConstraintType;
		}
	}
}
