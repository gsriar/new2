using System;
namespace X2SQL
{
	public abstract class TableLevelConstraint : SQLEntity
	{
		public TableLevelConstraintType TableLevelConstraintType
		{
			get;
			set;
		}
        
		public TableLevelConstraint(TableLevelConstraintType tableLevelConstraintType, string name) : base(SQLEntityType.Constraint, name)
		{
			this.TableLevelConstraintType = tableLevelConstraintType;
		}
	}
}
