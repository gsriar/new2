using System;
namespace X2SQL
{
	public class DefaultValueContstraint : ColumnLevelConstraint
	{
		public string Value
		{
			get;
			set;
		}
		public DefaultValueContstraint(string name) : base(ColumnLevelConstraintType.DEFAULT, name)
		{
		}
	}
}
