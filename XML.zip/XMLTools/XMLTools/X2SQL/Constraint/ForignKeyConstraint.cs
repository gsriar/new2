using System;
using System.Collections.Generic;
namespace X2SQL
{
	public class ForeignKeyConstraint : TableLevelConstraint
	{
		public Table ChildTable
		{
			get;
			set;
		}
		public Table PrimaryTable
		{
			get;
			set;
		}

		public List<Column> PrimaryColumns
		{
			get;
			set;
		}
		public List<Column> ChildColumns
		{
			get;
			set;
		}
        
        public IEnumerable<string> PrimaryColumnNameList()
        {
            List<String> cols = new List<string>();
            foreach (var c in this.PrimaryColumns)
            {
                cols.Add(c.Name);
            }
            return cols;
        }

        public IEnumerable<string> ChildColumnNameList()
        {
            List<String> cols = new List<string>();
            foreach (var c in this.ChildColumns)
            {
                cols.Add(c.Name);
            }
            return cols;
        }

		public ForeignKeyConstraint(string name) : base(TableLevelConstraintType.FOREIGNKEY, name)
        {
            ChildColumns = new List<Column>();
            PrimaryColumns = new List<Column>();
		}
	}
}
