using System;
using System.Collections.Generic;
namespace X2SQL
{
	public class CheckContstraint : ColumnLevelConstraint
	{
		public CheckContstraintType CheckContstraintType
		{
			get;
			set;
		}
		public List<string> Values
		{
			get;
			set;
		}
		public CheckContstraint(string name) : base(ColumnLevelConstraintType.CHECK, name)
		{
		}
	}
}
