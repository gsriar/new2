using System;
using System.Collections.Generic;
namespace X2SQL
{
	public class PrimaryKeyConstraint : TableLevelConstraint
	{
		public Table Table
		{
			get;
			set;
		}
		public List<Column> Columns
		{
			get;
			set;
		}

        public IEnumerable<string> ColumnNames()
        {
            List<String> cols = new List<string>();
            foreach (var c in this.Columns)
            {
                cols.Add(c.Name);
            }
            return cols;
        }

		public PrimaryKeyConstraint(string name) : base(TableLevelConstraintType.PRIMARYKEY, name)
		{
            Columns = new List<Column>();
		}
	}
}
