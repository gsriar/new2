﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using X2SQL.EntityData;
using X2SQL.SQLWrite;
using XPassThrough;
using SharedHelper;

namespace X2SQL.Prepare
{
    class DMLParser
    {
        protected XMeta xMeta = null;
        protected SQLEntityContainer sqlEntityContainer = null;

        private DataTableCollection dtColl = null;

        public DMLParser(SQLEntityContainer sqlEntityContainer, XMeta xMeta)
        {
            this.sqlEntityContainer = sqlEntityContainer;
            this.xMeta = xMeta;
        }

        public void PrepareXML(TextWriter textWriter, TransformationOption options)
        {
            PrepareDataTableCollection(options);
            DMLWriter dmlWriter = new DMLWriter(textWriter);
            dmlWriter.SQLWrite(sqlEntityContainer, 0);
        }

        public DataTableCollection PrepareDataTableCollection(TransformationOption options)
        {
            Row row = PrepareDataRow(xMeta.GetXDocument().Root as XElement, null, options);

            PrepareData(xMeta.GetXDocument().Root as XElement, row, options);
            return dtColl;
        }

        public void PrepareData(XElement xml, Row pkRows, TransformationOption options)
        {
            foreach (XElement topNode in xml.Nodes().Where(n => n is XElement))
            {
                indent++;
                var xtreeNode = xMeta.NodeCollection.FirstOrDefault(x => x.QualifiedName.Name == topNode.Name.LocalName && x.QualifiedName.NameSpace == topNode.Name.Namespace);
                if (xtreeNode != null)
                {
                    Row row = PrepareDataRow(topNode, pkRows, options);

                    foreach (XElement child in topNode.Nodes().Where(x => x is XElement))
                    {
                        //VARIFY THAT NODE(#child) IS not an AN ATTRIBUTE(of type element) OF PARENT
                        var att = xtreeNode.AttributeCollection.FirstOrDefault(f => f.QualifiedName.ShallowSame(child.Name));
                        if (att == null)
                        {
                            indent++;

                            Row row1 = PrepareDataRow(child as XElement, row, options);

                            PrepareData(child, row1 ?? row, options);
                            indent--;
                        }
                    }

                }
                indent--;
            }

        }
        int indent = 0;
        List<string> exList = new List<string>();
        public Row PrepareDataRow(XElement xml, Row fkRow, TransformationOption options)
        {
            var xtreeNode = xMeta.NodeCollection.FirstOrDefault(x => x.QualifiedName.Name == xml.Name.LocalName && x.QualifiedName.NameSpace == xml.Name.Namespace);

            if (xtreeNode != null)
            {
                Table table = sqlEntityContainer.Tables.FirstOrDefault(f => f.Name == xtreeNode.QualifiedName.CustomName);

                if (table == null)
                {
                    Append(string.Format("{0}#null table", xtreeNode.QualifiedName.CustomName), indent);
                    return null;
                }

                Row newrow = table.NewRow();
                string s = GeneratePrimary(newrow) as string;
                Append(table.Name + " # " + s, indent);

                List<Tuple<string, string, string>> rowDataArray = new List<Tuple<string, string, string>>();

                foreach (var xtNodeAttributes in xtreeNode.AttributeCollection)
                {
                    var colValue = ColumnValueTuple(xtNodeAttributes, xml);
                    var col = table[colValue.Item1];

                    if (col == null)
                    {
                        throw new Exception("attr Col is null");
                    }

                    newrow[col] = colValue.Item3.TrimSpecial();
                }

                if (table.Columns.FirstOrDefault(c => c.Name == Constant.InnerText) != null)
                {
                    var col = table[Constant.InnerText];

                    if (col == null)
                    {
                        throw new Exception("Col is null");
                    }

                    newrow[col] = xml.Value.TrimSpecial();
                }

                if (fkRow != null && options.DefinitionOption.ForeignKeyOptions.GenerateReferenceForeignKeys)
                {

                    Table primaryTable = fkRow.Table;
                    Table childTable = table;

                    List<TableLevelConstraint> check = sqlEntityContainer.TableLevelConstraints.FindAll(c => c is ForeignKeyConstraint).
                                   FindAll(c =>
                                   {
                                       var fk = c as ForeignKeyConstraint;
                                       return fk.ChildTable == childTable && fk.PrimaryTable == primaryTable;
                                   });

                    foreach (ForeignKeyConstraint fk in check)
                    {
                        for (int p = 0; p < fk.PrimaryColumns.Count; p++)
                        {
                            Column primaryColumn = fk.PrimaryColumns[p];

                            Column childColumn = fk.ChildColumns[p];
                            if (childColumn == null)
                            {
                                string msg = string.Format("Column [{0}] of [{1}] is not found in [{2}]", primaryColumn.Name, fk.PrimaryTable.Name, table.Name);
                                throw new Exception(msg);
                            }

                            object o = newrow[childColumn];

                            if (o != null && o != fkRow[primaryColumn])
                            {
                                string info = string.Format("{0}{0}Primary Table :[{1}]{0}Primary Column:[{2} # {3}]{0}{0}Child Table:[{4}]{0}Child Column:[{5} # {6}]",
                                Environment.NewLine, primaryColumn.Table.Name, primaryColumn.DataTypeName, primaryColumn.Name,
                                   childColumn.Table.Name, childColumn.DataTypeName, childColumn.Name);

                                Append(info, indent);
                                throw new Exception(info);
                            }

                            newrow[childColumn] = fkRow[primaryColumn];

                        }

                    }

                }
                return newrow;
            }
            return null;
        }

        void Append(string s, int i)
        {
            exList.Add("".PadLeft(i * 4, ' ') + s);
        }

        private object GeneratePrimary(Row row)
        {
            StringBuilder res = new StringBuilder();
            foreach (var col in row.Columns.Find(f => f.IsKey))
            {
                if (col.AutoIncrement)
                {
                    row[col] = row.Table.RowCollection.Count() + 1;
                }
                else if (col.DataTypeName == SQLTypeHelper.Resolve(typeof(Guid)))
                {
                    row[col] = Guid.NewGuid().ToString().ToUpper();
                }
                else
                    throw new Exception("Could not generate primry key");
                res.Append(row[col] + " ");
            }
            return res.ToString();
        }


        public Tuple<string, string, string> ColumnValueTuple(XPassThrough.Attribute xttribute, XElement refXElement)
        {
            try
            {
                string resultValue = "";
                switch (xttribute.AttributeType)
                {
                    case AttributeType.Attribute:
                        var refXElementChileAttr = refXElement.Attribute(XName.Get(xttribute.QualifiedName.Name, xttribute.QualifiedName.NameSpaceName));
                        if (refXElementChileAttr != null)
                        {
                            resultValue = refXElementChileAttr.Value;
                        }
                        break;

                    case AttributeType.Element:
                        var refXElementChileElement = refXElement.Nodes().FirstOrDefault(f => !(f is XCData || f is XText) && (f as XElement).Name == XName.Get(xttribute.QualifiedName.Name, xttribute.QualifiedName.NameSpaceName)) as XElement;
                        if (refXElementChileElement != null)
                        {
                            resultValue = refXElementChileElement.Value;
                        }
                        break;

                    case AttributeType.Text:
                        resultValue = refXElement.Value;
                        break;
                }


                Tuple<string, string, string> tuple = new Tuple<string, string, string>(xttribute.QualifiedName.CustomName, xttribute.QualifiedName.NameSpace, resultValue);
                return tuple;
            }
            catch
            {
                throw new Exception(string.Format("Procedure:GetPasstroughAttributeValue"));
            }
        }

    }
}
