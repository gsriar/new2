﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using X2SQL.SQLWrite;
using XPassThrough;

namespace X2SQL.Prepare
{
    class DDLParser
    {
        protected XMeta xMeta = null;
        protected SQLEntityContainer sqlEntityContainer = null;

        public DDLParser(SQLEntityContainer sqlEntityContainer, XMeta xMeta)
        {
            this.sqlEntityContainer = sqlEntityContainer;
            this.xMeta = xMeta;
        }

        public string PrepareDDL(TransformationOption options)
        {
            StringBuilder sb = new StringBuilder();
            using (TextWriter textWriter = new StringWriter(sb))
            {
                Prepare(textWriter, options);
            }
            return sb.ToString();
        }

        public void Prepare(TextWriter textWriter, TransformationOption options)
        {
            SQLServerDDLWriter wr = new SQLServerDDLWriter(sqlEntityContainer, textWriter);
            wr.Write();
        }

    }
}
