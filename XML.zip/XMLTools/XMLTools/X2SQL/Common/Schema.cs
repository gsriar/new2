﻿using System;
using System.Data;

namespace X2SQL.Common
{
    public class ColumnSchema
    {
        
        public String ColumnName { get; set; }
      
        public Int32 ColumnOrdinal { get; set; }
      
        public Int32 ColumnSize { get; set; }
      
        public Int16 NumericPrecision { get; set; }
      
        public Int16 NumericScale { get; set; }
      
        public Boolean IsUnique { get; set; }
      
        public Boolean IsKey { get; set; }
      
        public string DataType { get; set; }
      
        public Boolean AllowDBNull { get; set; }
      
        public Boolean IsIdentity { get; set; }
      
        public Boolean IsAutoIncrement { get; set; }
      
        public Boolean IsLong { get; set; }
      
        public String DataTypeName { get; set; }
      
        public string DefaultValue { get; set; }
    }
}
