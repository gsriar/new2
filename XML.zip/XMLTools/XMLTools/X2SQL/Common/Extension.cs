﻿using System;
using System.Collections.Generic;
using System.Linq;
using SharedHelper;

namespace X2SQL
{
    public static class Extension
    {
        public static string TransformSQLValue(this string name, Column column)
        {
            return name;
        }
        
        public static IEnumerable<T> Find<T>(this IEnumerable<T> enumerable, Func<T, bool> predicate)
        {
            foreach (var current in enumerable)
            {
                if (predicate(current))
                {
                    yield return current;
                }
            }
            yield break;
        }
    }
}
