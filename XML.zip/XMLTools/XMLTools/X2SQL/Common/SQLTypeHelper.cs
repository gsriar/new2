﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace X2SQL
{
    public class SQLTypeConstant
    {
        public const string smallint = "smallint";
        public const string INT = "int";
        public const string DECIMAL = "decimal";
        public const string uniqueidentifier = "uniqueidentifier";
        public const string varchar = "varchar";
        public const string CHAR = "char";
    }

    public static class SQLTypeHelper
    {
        private static readonly Dictionary<Type, string> Aliases =
             new Dictionary<Type, string>()
            {
                { typeof(short), "smallint" },
                { typeof(int), "int" },
                { typeof(Int64), "BigInt" },
                //{ typeof(double), "decimal" },
                //{ typeof(decimal), "decimal" },
                { typeof(char), "char" },
                { typeof(string), "varchar" },
                { typeof(Guid), "uniqueidentifier" }
            };

        public static string Resolve(Type t)
        {
            if (Aliases.ContainsKey(t))
                return Aliases[t];
            else
                return null;
        }

    }
}
