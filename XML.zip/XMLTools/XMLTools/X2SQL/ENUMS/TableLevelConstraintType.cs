using System;
namespace X2SQL
{
	public enum TableLevelConstraintType
	{
		CHECK,
		PRIMARYKEY,
		FOREIGNKEY,
		UNIQUE
	}
}
