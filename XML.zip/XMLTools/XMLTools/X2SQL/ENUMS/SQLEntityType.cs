using System;

namespace X2SQL
{
	public enum SQLEntityType
	{
		Table,
		Column,
		Constraint,
        EntityContainer
	}
}
