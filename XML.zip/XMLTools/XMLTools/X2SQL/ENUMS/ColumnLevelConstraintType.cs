using System;
namespace X2SQL
{
	public enum ColumnLevelConstraintType
	{
		DEFAULT,
		CHECK
	}
}
