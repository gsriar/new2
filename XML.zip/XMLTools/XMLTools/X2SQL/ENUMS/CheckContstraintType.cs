using System;
namespace X2SQL
{
	public enum CheckContstraintType
	{
		RegularExpression,
		Like,
		Between,
		IN
	}
}
