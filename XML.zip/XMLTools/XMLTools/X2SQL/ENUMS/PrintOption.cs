﻿public enum PrintMode
{
    INLINE,
    OUTLINE
}
