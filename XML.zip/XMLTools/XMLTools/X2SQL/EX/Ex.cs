﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace X2SQL.EX
{
    [Serializable]
    public class XException : Exception
    {
        public XException()
            : base() { }

        public XException(string message)
            : base(message) { }

        public XException(string format, params object[] args)
            : base(string.Format(format, args)) { }

        public XException(string message, Exception innerException)
            : base(message, innerException) { }

        public XException(string format, Exception innerException, params object[] args)
            : base(string.Format(format, args), innerException) { }

        protected XException(SerializationInfo info, StreamingContext context)
            : base(info, context) { }
    }
}
