﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XPassThrough;

namespace X2SQL
{
    public enum AutoGenratedPrimaryKeyType
    {
        Identity,
        GUID
    }

    public enum PrimaryKeyPrefixType
    {
        None,
        TableName,
        Constant
    }
    
    public class TransformationOption
    {
        public TransformationOption()
        {
            DefinitionOption = new DefinationOption();
            ManipulationOption = new ManipulationOption();
        }
        public CharacterCasingOption CharacterCasingOption { get; set; }
        public DefinationOption DefinitionOption { get; set; }
        public ManipulationOption ManipulationOption { get; set; }
    }

    public class PrimaryKeyOption
    {
        public PrimaryKeyOption()
        {
            AutoGeneratePrimaryKey = true;
            PrimaryKeyPrefixType = global::X2SQL.PrimaryKeyPrefixType.TableName;  
            PrefixTableName = true;
            PrimaryKeyName = "ID";
            this.AutoGenratedPrimaryKeyType = global::X2SQL.AutoGenratedPrimaryKeyType.GUID;
        }

        public bool AutoGeneratePrimaryKey { get; set; }
        public AutoGenratedPrimaryKeyType AutoGenratedPrimaryKeyType { get; set; }

        public PrimaryKeyPrefixType PrimaryKeyPrefixType { get; private set; }
        public String PrimaryKeyPrefix { get; private set; }
        public String PrimaryKeyName { get; private set; }
        public bool PrefixTableName { get; private set; }
    }

    public class ForeignKeyOption
    {
        public ForeignKeyOption()
        {
            GenerateReferenceForeignKeys = true;
        }

        public bool GenerateReferenceForeignKeys { get; set; }
    }

    public class DefinationOption
    {
        public DefinationOption()
        {            
            PrimaryKeyOptions = new PrimaryKeyOption();
            ForeignKeyOptions = new ForeignKeyOption();
        }

        public PrimaryKeyOption PrimaryKeyOptions { get; set; }
        public ForeignKeyOption ForeignKeyOptions { get; set; }
    }


    public class ManipulationOption
    {

    }
}