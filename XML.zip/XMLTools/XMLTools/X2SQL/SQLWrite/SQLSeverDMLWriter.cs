﻿using System;
using System.IO;
using X2SQL.EntityData;

namespace X2SQL.SQLWrite
{
    class DMLWriter 
    {
        protected Pen Pen { get; private set; }

        public DMLWriter(TextWriter pen)
        {
            this.Pen = new Pen(pen);
        }
        
        protected void SQLWrite(DataTable member, int indent)
        {
            foreach (DataRow row in member.Rows)
            {
                this.Pen.AppendFormated(indent, "INSERT INTO [{0}].[{1}] (", row.DataTable.Table.Owner, row.DataTable.Table.Name);
                for (int i = 0; i < row.DataColumnCollection.Count; i++)
                {
                    var col = row.DataColumnCollection[i];
                    Pen.AppendFormated(0, "[{0}]{1}", col.Column.Name, i < row.DataColumnCollection.Count - 1 ? ", " : "");
                }

                Pen.Append(") VALUES (");
                for (int i = 0; i < row.DataColumnCollection.Count; i++)
                {
                    var col = row.DataColumnCollection[i];

                    switch (col.Column.DataTypeName.ToLower())
                    {
                        case SQLTypeConstant.varchar:
                        case SQLTypeConstant.uniqueidentifier:
                            Pen.AppendFormated(0, "'{0}'{1}", SQLEncode(col.Value), i < row.DataColumnCollection.Count - 1 ? ", " : "");
                            break;
                        default:
                            if (col.Column.AllowDBNull && col.Value == null || string.IsNullOrWhiteSpace((col.Value as string)))
                                Pen.AppendFormated(0, "{0}{1}", "NULL", i < row.DataColumnCollection.Count - 1 ? ", " : "");
                            else
                                Pen.AppendFormated(0, "{0}{1}", col.Value, i < row.DataColumnCollection.Count - 1 ? ", " : "");
                            break;
                    }
                }
                Pen.Append(");");
                this.Pen.WriteLine();
            }
            this.Pen.WriteLine();
        }


        public object SQLEncode(object s)
        {
            if (s != null && s is string)
            {
                if( (s as string).IndexOf('\'')>-1)
                {
                    return (s as string).Replace("\'", "\'\'");
                }
            }

            return s;
        }

        public void SQLWrite(Table member, int indent)
        {
            int i = 0, j = 0;
            foreach (var s in member.Columns)
                i++;

            foreach (var row in member.RowCollection)
            {
                this.Pen.AppendFormated(indent, "INSERT INTO [{0}].[{1}] (", row.Table.Owner, row.Table.Name);

                j = 0;
                foreach (var col in member.Columns)
                {
                    Pen.AppendFormated(0, "[{0}]{1}", col.Name, ++j < i ? ", " : "");
                }
                Pen.Append(") VALUES (");

                j = 0;
                foreach (var col in row.Columns)
                {
                    switch (col.DataTypeName.ToLower())
                    {
                        case SQLTypeConstant.varchar:
                        case SQLTypeConstant.uniqueidentifier:
                            Pen.AppendFormated(0, "'{0}'{1}", SQLEncode(row[col]), ++j < i ? ", " : "");
                            break;
                        default:
                            if (col.AllowDBNull && row[col] == null || string.IsNullOrWhiteSpace((row[col] as string)))
                                Pen.AppendFormated(0, "{0}{1}", "NULL", ++j < i ? ", " : "");
                            else

                                Pen.AppendFormated(0, "{0}{1}", row[col], ++j < i ? ", " : "");
                            break;
                    }
                }

                Pen.Append(");");
                this.Pen.WriteLine();
            }

            this.Pen.WriteLine();
        }

        public void SQLWrite(DataTableCollection member, int indent)
        {
            foreach (var dtb in member.DataTables())
            {
                SQLWrite(dtb, indent);
            }
        }

        public void SQLWrite(SQLEntityContainer member, int indent)
        {
            foreach (var dtb in member.Tables)
            {
                SQLWrite(dtb, indent);
            }
        }
    }
}
