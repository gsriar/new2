﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace X2SQL
{
    public class SQLServerDDLWriter
    {
        protected Pen Pen { get; private set; }
        private SQLEntity sqlEntity = null;

        public SQLServerDDLWriter(SQLEntity entity, TextWriter pen)
        {
            this.sqlEntity = entity;
            this.Pen = new Pen(pen);
        }

        public void Write()
        {
            this.SQLWrite(sqlEntity, 0);
        }

        public void SQLWrite(SQLEntity member, int indent)
        {
            if (member is Table)
            {
                this.SQLWrite(member as Table, indent);
            }
            else if (member is TableLevelConstraint)
            {
                this.SQLWrite(member as TableLevelConstraint, indent, PrintMode.OUTLINE);
            }
            else if (member is Column)
            {
                this.SQLWrite(member as Column, indent);
            }
            else if (member is ColumnLevelConstraint)
            {
                this.SQLWrite(member as ColumnLevelConstraint, indent, PrintMode.OUTLINE);
            }
            else if (member is SQLEntityContainer)
            {
                this.SQLWrite(member as SQLEntityContainer, indent);
            }
            else
            {
                throw new ArgumentException("Invalid SQL Entity");
            }
        }


        protected void SQLWrite(SQLEntityContainer member, int indent)
        {
            List<Table> tables = new List<Table>(member.Tables);
            tables.Reverse();
            foreach (Table t in tables)
            {
                this.WriteDelete(t, 0);
                this.Pen.WriteLine();
            }

            foreach (Table t in member.Tables)
            {
                this.SQLWrite(t, 0);
                this.Pen.WriteLine();
            }

            foreach (SQLEntity t in member.TableLevelConstraints)
            {
                this.SQLWrite(t, 0);
                this.Pen.WriteLine();
            }
        }

        protected void SQLWrite(Table member, int indent)
        {
            this.Pen.WriteFormatedLine(indent, "CREATE TABLE [{0}].[{1}]", member.Owner, member.Name);

            this.Pen.WriteLine(Constants.roundOpen);

            this.SQLWrite(member.Columns, indent + 1);

            if (member.PrimaryKeyConstraint != null)
            {
                this.Pen.Append(Constants.comma);
                this.Pen.WriteLine();
                this.SQLWrite(member.PrimaryKeyConstraint, indent + 1, PrintMode.INLINE);
            }
            this.Pen.WriteLine();
            this.Pen.WriteLine(Constants.roundClose);

        }

        protected void WriteDelete(Table member, int indent)
        {
            this.Pen.WriteFormatedLine(indent, @"IF OBJECT_ID('{0}.{1}', 'U') IS NOT NULL", member.Owner, member.Name);
            this.Pen.WriteFormatedLine(indent + 1, @"DROP TABLE {0}.{1}", member.Owner, member.Name);
        }

        protected void SQLWrite(Column member, int indent)
        {
            if (member.Name.ToUpper() == "COMMENT" && member.Table.Name == "ClaimComment")
            {
            }
            string dataTypeName = member.DataTypeName.ToUpper();

            if (member.DataTypeName == SQLTypeHelper.Resolve(typeof(string)) && member.MaxLength > 8000)
                dataTypeName = "TEXT";

            this.Pen.AppendFormated(indent, "[{0}]\t\t{1}", member.Name, dataTypeName);
            int i = 0;
            if (member.DataTypeName == SQLTypeHelper.Resolve(typeof(string)) && member.MaxLength <= 8000)
            {
                this.Pen.AppendFormated(0, " ({0})", member.MaxLength);
                i++;
            }

            if (member.DataTypeName == SQLTypeHelper.Resolve(typeof(decimal)))
            {
                this.Pen.AppendFormated(0, " (10,2)");
                i++;
            }

            if (member.AutoIncrement)
            {
                this.Pen.AppendFormated(1, "NOT NULL", member.AutoIncrementSeed, member.AutoIncrementStep);
            }
            else
                this.Pen.AppendFormated(1, "{0}", member.AllowDBNull ? "NULL" : "NOT NULL");
        }

        protected void SQLWrite(IEnumerable<Column> member, int indent)
        {
            int count = member.Count();
            foreach (Column clm in member)
            {
                this.SQLWrite(clm, indent);
                count--;

                if (count > 0)
                {
                    this.Pen.Append(Constants.comma);

                    this.Pen.WriteLine();
                }

            }
        }

        protected void SQLWrite(ColumnLevelConstraint member, int indent, PrintMode mode)
        {
            throw new NotImplementedException();
        }

        protected void SQLWrite(TableLevelConstraint member, int indent, PrintMode mode)
        {
            if (member == null)
                return;

            if (member is PrimaryKeyConstraint)
            {
                var primaryKey = member as PrimaryKeyConstraint;
                switch (mode)
                {
                    case PrintMode.INLINE:
                        this.Pen.AppendFormated(indent, "CONSTRAINT {0} PRIMARY KEY ({1})",
                          primaryKey.Name, SharedHelper.StringHelper.ConcatFormat(primaryKey.ColumnNames(), ",", "[", "]"));
                        break;
                    case PrintMode.OUTLINE:
                        this.Pen.AppendFormated(indent, "ALTER TABLE {0} CONSTRAINT {1} PRIMARY KEY ({2})",
                          primaryKey.Table.Name, primaryKey.Name, SharedHelper.StringHelper.ConcatFormat(primaryKey.ColumnNames(), ",", "[", "]"));

                        break;
                }
            }

            else if (member is ForeignKeyConstraint)
            {
                var foreignKey = member as ForeignKeyConstraint;

                switch (mode)
                {
                    case PrintMode.INLINE:   /*CONSTRAINT fk_PerOrders FOREIGN KEY (P_Id) REFERENCES Persons(P_Id)*/
                        this.Pen.AppendFormated(indent, "CONSTRAINT {0} FOREIGN KEY ({1}) REFERENCES {2}({3})",
                                                        foreignKey.Name,
                                                        SharedHelper.StringHelper.ConcatFormat(foreignKey.PrimaryColumnNameList(), ",", "[", "]"),
                                                        foreignKey.PrimaryTable.Name,
                                                        SharedHelper.StringHelper.ConcatFormat(foreignKey.ChildColumnNameList(), ",", "[", "]"));
                        break;
                    case PrintMode.OUTLINE:
                        this.Pen.AppendFormated(indent, "ALTER TABLE {0} ADD CONSTRAINT {1} FOREIGN KEY ({2}) REFERENCES {3}({4})",
                                                        foreignKey.ChildTable.Name,
                                                        foreignKey.Name,
                                                        SharedHelper.StringHelper.ConcatFormat(foreignKey.PrimaryColumnNameList(), ",", "[", "]"),
                                                        foreignKey.PrimaryTable.Name,
                                                        SharedHelper.StringHelper.ConcatFormat(foreignKey.ChildColumnNameList(), ",", "[", "]"));

                        break;
                }
                this.Pen.WriteLine();
            }
            else
            {
                throw new NotImplementedException();
            }
        }
    }
}
