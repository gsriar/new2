﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using XPassThrough;
using System.Collections.Generic;
using X2SQL.EntityData;
using X2SQL.Prepare;

namespace X2SQL
{
    public class X2SQL
    {
        public static readonly X2SQL Instance = new X2SQL();
        private XMeta xMeta = null;
        private SQLEntityContainer sqlEntityContainer = null;
        DataTableCollection dtColl = new DataTableCollection();

        public void BuildSQL(XDocument xml, TransformationOption options, TextWriter textWriter)
        {
            xMeta = XTreeBuilder.Instance.BuidXTree(xml);
            xMeta.CleanAndApplyQualifiedName(options.CharacterCasingOption);
            SQLEntityParser parser = new SQLEntityParser();
            var sqlEntityContainer = parser.Parse(xMeta, options);

            DDLParser ddl = new DDLParser(sqlEntityContainer, xMeta);
            DMLParser dml = new DMLParser(sqlEntityContainer, xMeta);


            ddl.Prepare(textWriter, options);
            dml.PrepareXML(textWriter, options);

        }

        public string BuildSQL(XDocument xml, TransformationOption options)
        {
            StringBuilder sb = new StringBuilder();

            using (TextWriter writer = new StringWriter(sb))
            {
                BuildSQL(xml, options, writer);
            }
            return sb.ToString();
        }


        public void PrepareData(XElement xml, List<DataColumn> primaryKeyDataColumn, TransformationOption options)
        {
            foreach (XElement topNode in xml.Nodes().Where(n => n is XElement))
            {
                var xtreeNode = xMeta.NodeCollection.FirstOrDefault(x => x.QualifiedName.Name == topNode.Name.LocalName && x.QualifiedName.NameSpace == topNode.Name.Namespace);
                if (xtreeNode != null)
                {
                    DataRow row = PrepareDataRow(topNode, primaryKeyDataColumn, options);
                    foreach (XElement child in topNode.Nodes().Where(x => x is XElement))
                    {
                        DataRow row1 = PrepareDataRow(child as XElement, row.PrimaryDataColumn(), options);
                        PrepareData(child, (row1 ?? row).PrimaryDataColumn(), options);
                    }
                }
            }
        }

        public DataRow PrepareDataRow(XElement xml, List<DataColumn> primaryKeyDataColumn, TransformationOption options)
        {
            var xtreeNode = xMeta.NodeCollection.FirstOrDefault(x => x.QualifiedName.Name == xml.Name.LocalName && x.QualifiedName.NameSpace == xml.Name.Namespace);
            if (xtreeNode != null)
            {
                Table table = sqlEntityContainer.Tables.First(f => f.Name == xtreeNode.QualifiedName.CustomName);

                List<Tuple<string, string, string>> rowDataArray = new List<Tuple<string, string, string>>();

                foreach (var xtNodeAttributes in xtreeNode.AttributeCollection)
                {
                    rowDataArray.Add(ColumnValueTuple(xtNodeAttributes, xml));
                }

                if (table.Columns.FirstOrDefault(c => c.Name == Constant.InnerText) != null)
                {
                    rowDataArray.Add(new Tuple<string, string, string>(Constant.InnerText, string.Empty, xml.Value));
                }

                DataRow row = dtColl[table].AddRow(rowDataArray);

                if (primaryKeyDataColumn != null)
                {
                    foreach (var parentPKCol in primaryKeyDataColumn)
                    {
                        var tableCol = table.Columns.FirstOrDefault(f => f.Name == parentPKCol.Column.Name);

                        if (tableCol != null)
                        {
                            row.UpdateColumn(tableCol, parentPKCol.Value.ToString());
                        }
                    }
                }

                return row;
            }

            return null;
        }

        public Tuple<string, string, string> ColumnValueTuple(XPassThrough.Attribute xttribute, XElement refXElement)
        {
            string resultValue = "";
            switch (xttribute.AttributeType)
            {
                case AttributeType.Attribute:
                    {
                        var refXmlCandidate = refXElement.Attribute(XName.Get(xttribute.QualifiedName.Name, xttribute.QualifiedName.NameSpaceName));
                        if (refXmlCandidate != null)
                        {
                            resultValue = refXmlCandidate.Value;
                        }
                    }
                    break;
                case AttributeType.Element:
                    {
                        var refXmlCandidate = refXElement.Nodes().First(f => (f as XElement).Name == XName.Get(xttribute.QualifiedName.Name, xttribute.QualifiedName.NameSpaceName)) as XElement;
                        if (refXmlCandidate != null)
                        {
                            resultValue = refXmlCandidate.Value;
                        }
                    }
                    break;
                case AttributeType.Text:
                    {
                        resultValue = refXElement.Value;
                    }
                    break;
            }



            Tuple<string, string, string> tuple = new Tuple<string, string, string>(xttribute.QualifiedName.Name, xttribute.QualifiedName.NameSpace, resultValue);
            return tuple;
        }

    }
}
