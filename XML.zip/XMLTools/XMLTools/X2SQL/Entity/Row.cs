﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace X2SQL.EntityData
{
    public class Row
    {
        private object[] Values;

        public Table Table { get; private set; }

        public IEnumerable<Column> Columns
        {
            get
            {
                return this.Table.Columns;
            }
        }

        internal Row(Table table)
        {
            this.Table = table;
            Values = new object[table.Columns.Count()];
        }

        public object this[int i]
        {
            get
            {
                return Values[i];
            }
            set
            {
                Values[i] = value;
            }
        }


        public object this[Column col]
        {
            get
            {
                if (col.Table == this.Table)
                    return this[col.Ordinal];
                else
                {
                    throw new Exception("Column does not belong to this table");
                }
            }

            set
            {
                if (col.Table == this.Table)
                    this[col.Ordinal] = value;
                else
                {
                    throw new Exception("Column does not belong to this table");
                }
            }

        }


    }
}
