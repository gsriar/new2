﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace X2SQL
{
    public class SQLEntityContainer : SQLEntity
    {
        public SQLEntityContainer()
            : base(SQLEntityType.EntityContainer, "")
        {
            Tables = new List<Table>();
            TableLevelConstraints = new List<TableLevelConstraint>();
        }

        public List<Table> Tables { get; set; }
        public List<TableLevelConstraint> TableLevelConstraints { get; set; }
    }
}
