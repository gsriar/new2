using System;
namespace X2SQL
{
    public abstract class SQLEntity
    {
        public SQLEntityType SQLEntityType
        {
            get;
            set;
        }

        private string _name = "";
            
        public string Name
        {
            get { return _name; }
            set {
                string oldVal=_name;
                _name = value;
                if (OnNameChange != null && oldVal != value)
                    OnNameChange(_name, value);
            }
        }

        public string RawName
        {
            get;
            set;
        }

        public event Action<string, string> OnNameChange;

        public SQLEntity(SQLEntityType sQLEntityType, string Name)
        {
            this.SQLEntityType = this.SQLEntityType;
            this.Name = Name;
            this.RawName = Name;
        }
    }
}
