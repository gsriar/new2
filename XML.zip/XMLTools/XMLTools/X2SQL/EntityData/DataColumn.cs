﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace X2SQL.EntityData
{
    public class DataColumn
    {
        public DataRow EntityRow { get; private set; }

        public DataColumn(DataRow Row, Column Column)
        {
            this.EntityRow = Row;
            this.Column = Column;
        }

        public Column Column { get; private set; }

        public object Value { get; set; }
    }
}
