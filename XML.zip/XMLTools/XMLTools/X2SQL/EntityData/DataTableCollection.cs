﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace X2SQL.EntityData
{
    public class DataTableCollection
    {
        List<DataTable> dt = new List<DataTable>();

        public DataTable this[Table table]
        {
            get
            {
                var dt = this.dt.FirstOrDefault(o => o.Table == table);
                if (dt == null)
                {
                    dt = new DataTable(table);
                    this.dt.Add(dt);
                }
                return dt;
            }
        }


        public IEnumerable<DataTable> DataTables()
        {
            return dt;
        }

    }
}
