﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace X2SQL.EntityData
{
    public class DataRow
    {
        public DataTable DataTable { get; private set; }
        public List<DataColumn> DataColumnCollection = new List<DataColumn>();
        public int Identity = 0;

        public DataRow(DataTable table)
        {
            this.DataTable = table;
            Identity = table.Rows.Count + 1;
        }

        public DataColumn UpdateColumn(Tuple<string, string, string> columnData)
        {
            Column col = this.DataTable.Table.Columns.First(f => f.RawName == columnData.Item1);

            var dc = this.DataColumnCollection.FirstOrDefault(c => c.Column == col);
            if (dc == null)
            {
                dc = new DataColumn(this, col);
                DataColumnCollection.Add(dc);
            }
            dc.Value = columnData.Item3;

            return dc;
        }

        public DataColumn UpdateColumn(Column col,string Value)
        {
            if (this.DataTable.Table.Columns.FirstOrDefault(f => f == col)==null)
            {
                throw new Exception("Column does not belong to table");
            }

            var dc = this.DataColumnCollection.FirstOrDefault(c => c.Column == col);
            if (dc == null)
            {
                dc = new DataColumn(this, col);
                DataColumnCollection.Add(dc);
            }
            dc.Value = Value;

            return dc;
        }

        public List<DataColumn> PrimaryDataColumn()
        {
            return this.DataColumnCollection.FindAll(f => f.Column.IsKey);
        }
    }
}
