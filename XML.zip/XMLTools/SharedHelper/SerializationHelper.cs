﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace SharedHelper
{
    public static class SerializationHelper
    {
        public static string Serialize<T>(T dataToSerialize)
        {
            StringBuilder sb = new StringBuilder();
            using (StringWriter stream = new StringWriter(sb))
            {
                Type t = typeof(T);
                XmlSerializer serializer = new XmlSerializer(t);
                XmlTextWriter writer = new XmlTextWriter(stream);
                writer.Formatting = Formatting.Indented;
                serializer.Serialize(writer, dataToSerialize);
                writer.Close();
            }
            return sb.ToString();
        }

        public static T Deserialize<T>(string filePath)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            T serializedData;

            using (Stream stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
            {
                serializedData = (T)serializer.Deserialize(stream);
            }
            return serializedData;

        }

        public static T DeserializeString<T>(string xml)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            T serializedData;


            using (Stream stream = StringHelper.StringToStream(xml))
            {
                serializedData = (T)serializer.Deserialize(stream);
            }

            return serializedData;

        }
    }
}
