﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;

namespace SharedHelper
{
    public class SQLHelper
    {
        static public int SQLExecute(String ConnectionString, string SQL)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQL, conn))
                {
                    cmd.CommandTimeout = 600;
                    conn.Open();
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        static public object ExecuteScalar(String ConnectionString, string SQL)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQL, conn))
                {
                    cmd.CommandTimeout = 600;
                    conn.Open();
                    object obj = cmd.ExecuteScalar();
                    return obj;
                }
            }
        }

        static public object ExecuteScalar(String ConnectionString, string SQL, List<SqlParameter> SqlParameterList)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQL, conn))
                {
                    if (SqlParameterList != null)
                        foreach (var par in SqlParameterList)
                            cmd.Parameters.Add(par);

                    cmd.CommandTimeout = 600;
                    conn.Open();
                    object obj = cmd.ExecuteScalar();
                    return obj;
                }
            }
        }

        static public DataTable ExecuteDataTable(String ConnectionString, string SQL)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlDataAdapter adp = new SqlDataAdapter(SQL, conn))
                {
                    DataTable dtb = new DataTable();
                    conn.Open();
                    adp.Fill(dtb);
                    return dtb;
                }
            }
        }

        static public DataTable ExecuteDataTable(String ConnectionString, string SQL, IEnumerable<SqlParameter> SqlParameterList)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(SQL, conn))
                {
                    if (SqlParameterList != null)
                        foreach (var par in SqlParameterList)
                            cmd.Parameters.Add(par);

                    using (SqlDataAdapter adp = new SqlDataAdapter(cmd))
                    {
                        DataTable dtb = new DataTable();
                        conn.Open();
                        adp.Fill(dtb);
                        return dtb;
                    }
                }
            }
        }

        public static string BuildConnectionString(string sServerName, string sDatabaseName)
        {
            String ConnectionString = null;

            if (!String.IsNullOrEmpty(sDatabaseName))
            {
                ConnectionString = @"Data Source=" + sServerName + " ;Integrated Security=True;database=" + sDatabaseName + ";";
            }
            else
            {
                ConnectionString = @"Data Source=" + sServerName + " ;Integrated Security=True;";
            }

            return ConnectionString;
        }

    }
}
