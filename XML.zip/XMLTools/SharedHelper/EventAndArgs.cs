﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedHelper
{
    public delegate void Update(object sender, NotificationArgs e);
    public delegate void Completed(object sender, CompletedArgs e);

    public enum NotificationType
    {
        ParameterUpdate
    }

    public enum Status
    {
        Inprogress,
        Success,
        Warning,
        Error,
    }

    public class NotificationArgs : EventArgs
    {
        public NotificationArgs(NotificationType Type, string Parameter, string Value)
        {
            this.Type = Type;
            this.Parameter = Parameter;
            this.Value = Value;
        }
        public NotificationType Type { get; private set; }
        public string Parameter { get; private set; }
        public string Value { get; private set; }
        public bool Cancel { get; set; }
        public string Status { get; set; }
    }

    public class CompletedArgs : EventArgs
    {
        public CompletedArgs(Status CompletionStatus, List<string> Messages)
        {
            this.CompletionStatus = CompletionStatus;
            this.Messages = Messages;
        }

        public Status CompletionStatus { get; private  set; }

        public List<string> Messages { get; private set; }
    }
}
