﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace SharedHelper
{
    public static class XMLHelper
    {
        public static string GetFullPath(this XElement elemnt)
        {
            List<string> names = new List<string>();
            XElement current = elemnt;
            names.Add(current.Name.GetQualifiedPath());
            while (current.Parent != null)
            {
                current = current.Parent;
                names.Add(current.Name.GetQualifiedPath());
            }

            names.Reverse();
            string s = "";
            names.ForEach(f => s += f + "/");
            return s;
        }

        public static string GetQualifiedPath(this XName name)
        {
            return string.Format("{0}.{1}", name.NamespaceName, name.LocalName);
        }



    }
}
