﻿
using System;

namespace SharedHelper
{
    public class TypeDefaultHelper
    {
        public static readonly TypeDefaultHelper Instance = new TypeDefaultHelper();
        public string GetDefault(string typeName)
        {
            Type ty = Type.GetType(typeName);
            if (ty == null)
            {
                ty = GetEnumType(typeName);
            }
            object obj = GetDefault(ty);

            if (obj != null)
                return obj.ToString();
            else
                return string.Empty;
        }

        public static Type GetEnumType(string enumName)
        {
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                var type = assembly.GetType(enumName);
                if (type == null)
                    continue;
                if (type.IsEnum)
                    return type;
            }
            return null;
        }

        public object GetDefault(Type t)
        {
            return this.GetType().GetMethod("GetDefaultGeneric").MakeGenericMethod(t).Invoke(this, null);
        }

        public T GetDefaultGeneric<T>()
        {
            return default(T);
        }
    }
}
