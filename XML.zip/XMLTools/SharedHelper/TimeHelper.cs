﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedHelper
{
    public static class DateTimeHelper
    {
        static public DateTime GetPacificStandardTime()
        {
            return GetDateTime("Pacific Standard Time");
        }

        static public DateTime GetDateTime(string TimeZoneID)
        {
            var zone = TimeZoneInfo.FindSystemTimeZoneById(TimeZoneID);
            var utcNow = DateTime.UtcNow;
            var pacificNow = TimeZoneInfo.ConvertTimeFromUtc(utcNow, zone);
            return pacificNow;
        }
    }
}
