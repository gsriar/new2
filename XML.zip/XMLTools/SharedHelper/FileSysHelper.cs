﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedHelper
{
    public static class FileSysHelper
    {
        public enum PathType
        {
            None,
            File,
            Directory
        }

        static public PathType FileType(string path)
        {
            if (!(File.Exists(path) || Directory.Exists(path)))
                return PathType.None;

            FileAttributes attr = File.GetAttributes(path);

            if ((attr & FileAttributes.Directory) == FileAttributes.Directory)
                return PathType.Directory;
            else
                return PathType.File;
        }


        const int BYTES_TO_READ = sizeof(Int64);

        public static bool FilesAreEqual(FileInfo first, FileInfo second)
        {
            if (first.Length != second.Length)
                return false;

            int iterations = (int)Math.Ceiling((double)first.Length / BYTES_TO_READ);

            using (FileStream fs1 = first.OpenRead())
            using (FileStream fs2 = second.OpenRead())
            {
                byte[] one = new byte[BYTES_TO_READ];
                byte[] two = new byte[BYTES_TO_READ];

                for (int i = 0; i < iterations; i++)
                {
                    fs1.Read(one, 0, BYTES_TO_READ);
                    fs2.Read(two, 0, BYTES_TO_READ);

                    if (BitConverter.ToInt64(one, 0) != BitConverter.ToInt64(two, 0))
                        return false;
                }
            }

            return true;
        }


        static public string CopyFile(string sourceFile, string destinationFolder, bool overwrite, string fileName = "")
        {
            FileInfo source = new FileInfo(sourceFile);

            if (!Directory.Exists(destinationFolder))
                Directory.CreateDirectory(destinationFolder);

            string CopyTo = Path.Combine(destinationFolder, string.IsNullOrWhiteSpace(fileName) ? source.Name : fileName);

            if (File.Exists(CopyTo))
                SetFileAttribute(CopyTo, FileAttributes.Normal);

            source.CopyTo(CopyTo, true);

            return CopyTo;
        }

        static public void SetFileAttribute(string FileName, FileAttributes fileAttribute)
        {
            File.SetAttributes(FileName, fileAttribute);
        }

        static public FileAttributes RemoveAttribute(FileAttributes attributes, FileAttributes attributesToRemove)
        {
            return attributes & ~attributesToRemove;
        }


        static public FileAttributes AddAttribute(FileAttributes attributes, FileAttributes attributesToAdd)
        {
            return attributes | ~attributesToAdd;
        }

        public static string ReadFileText(string file)
        {
            return File.ReadAllText(file, GetEncoding(file));
        }

        public static string[] ReadAllLines(string file)
        {
            return File.ReadAllLines(file, GetEncoding(file));
        }


        public static Encoding GetEncoding(string fileName)
        {
            using (StreamReader reader = new StreamReader(fileName, Encoding.Default, true))
            {
                reader.Peek(); // you need this!
                return reader.CurrentEncoding;
            }
        }

        public static void RemoveAttribute(string temp, FileAttributes attributesToRemove)
        {
            FileInfo source = new FileInfo(temp);
            FileAttributes attributes = source.Attributes;

            if ((attributes & FileAttributes.ReadOnly) == attributesToRemove)
            {
                attributes = FileSysHelper.RemoveAttribute(attributes, attributesToRemove);
                File.SetAttributes(source.FullName, attributes);
            }
        }

        public static void DeleteAllFilesFromFolder(string zipFolder)
        {
            var d = new DirectoryInfo(zipFolder);
            foreach (FileInfo f in d.EnumerateFiles())
            {
                RemoveAttribute(f.FullName, FileAttributes.ReadOnly);
                f.Delete();
            }
        }

        public static void CreateFolder(string output)
        {
            DirectoryInfo di = new DirectoryInfo(output);
            if (!di.Exists)
                di.Create();
        }


        static public void DeleteFile(string file)
        {
            FileInfo source = new FileInfo(file);

            if (source.Exists)
            {
                SetFileAttribute(source.FullName, FileAttributes.Normal);

                source.Delete();
            }
        }
    }
}
