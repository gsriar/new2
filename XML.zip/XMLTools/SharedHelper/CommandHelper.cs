﻿
using System.Diagnostics;

namespace SharedHelper
{
    public static class CommandHelper
    {
        static public void ExecuteCommand(string command, bool waitForExit = false, ProcessWindowStyle processWindowStyle = ProcessWindowStyle.Hidden)
        {
            using (Process P = new Process())
            {
                //Launch a standard hidden command window
                P.StartInfo.FileName = "cmd.exe";
                P.StartInfo.WindowStyle = processWindowStyle;
                P.StartInfo.CreateNoWindow = true;
                P.StartInfo.WorkingDirectory = "C:\\";
                //Needed to redirect standard error/output/input
                P.StartInfo.UseShellExecute = false;
                P.StartInfo.RedirectStandardInput = true;
                P.StartInfo.RedirectStandardOutput = true;

                //Start the process
                P.Start();

                //Begin async data reading
                P.BeginOutputReadLine();
                P.StandardInput.WriteLine(command);


                if (waitForExit)
                {
                    P.StandardInput.WriteLine("exit");
                    P.WaitForExit();
                }
            }
        }

        public static bool IsVisualStudioIDE
        {
            get
            {
                bool inIDE = false;
                string[] args = System.Environment.GetCommandLineArgs();
                if (args != null && args.Length > 0)
                {
                    string prgName = args[0].ToUpper();
                    inIDE = prgName.EndsWith("VSHOST.EXE");
                }
                return inIDE;
            }
        }

    }
}
