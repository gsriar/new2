﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace SharedHelper
{
    public static class DataHelper
    {
        static public string ConvertToCSV(DataTable table)
        {
            return ConvertToDelimted(table, ",", 500, false);
        }


        static public string ConvertToDelimted(DataTable table, string delimiter, int trimLength, bool showNULL)
        {
            StringBuilder content = new StringBuilder();

            if (table.Rows.Count > 0)
            {
                DataRow dr1 = (DataRow)table.Rows[0];
                int intColumnCount = dr1.Table.Columns.Count;
                int index = 1;

                //add column names
                foreach (DataColumn item in dr1.Table.Columns)
                {
                    content.Append(String.Format("\"{0}\"", item.ColumnName));
                    if (index < intColumnCount)
                        content.Append(delimiter);
                    else
                        content.Append("\r\n");
                    index++;
                }

                //add column data
                foreach (DataRow currentRow in table.Rows)
                {
                    for (int y = 0; y <= intColumnCount - 1; y++)
                    {
                        string result;
                        if (currentRow[y] is string && currentRow[y] != DBNull.Value && currentRow[y] != null)
                        {
                            result = currentRow[y] as string;
                            if ((currentRow[y] as string).IndexOf('\n') > -1)
                                result = (currentRow[y] as string).Replace('\n', '\n');

                            if ((currentRow[y] as string).IndexOf('\r') > -1)
                                result = (currentRow[y] as string).Replace('\r', '\r');

                            if ((currentRow[y] as string).Length > trimLength)
                                currentRow[y] = (currentRow[y] as string).Remove(trimLength);
                        }
                        else if (currentRow[y] is DateTime)
                            result = string.Format("{0:s}", currentRow[y]);
                        else
                            result = currentRow[y] == DBNull.Value && showNULL ? "NULL" : currentRow[y].ToString();


                        content.Append("\"" + result + "\"");

                        if (y < intColumnCount - 1 && y >= 0)
                            content.Append(delimiter);
                    }
                    content.Append("\r\n");
                }

            }

            return content.ToString();
        }


        static public string DataTableToFixedLength(DataTable table, int trimLength, string saparator, bool showNULL)
        {
            StringBuilder content = new StringBuilder();

            if (table.Rows.Count > 0)
            {
                List<int> arr = new List<int>(table.Columns.Count);
                for (int i = 0; i < table.Columns.Count; i++)
                    arr.Add(0);

                DataRow dr1 = (DataRow)table.Rows[0];
                int intColumnCount = dr1.Table.Columns.Count;


                foreach (DataRow currentRow in table.Rows)
                {
                    string strRow = string.Empty;
                    for (int y = 0; y <= intColumnCount - 1; y++)
                    {
                        if (currentRow[y] is string)
                        {
                            var v = currentRow[y] as string;

                            if (v != null)
                            {
                                if (v.IndexOf('\n') > -1 || v.IndexOf('\r') > -1)
                                {
                                    v = v.Replace('\n', ' ');
                                    v = v.Replace('\r', ' ');
                                    currentRow[y] = v;
                                }
                                arr[y] = v.Length > arr[y] ? v.Length : arr[y];
                                if (arr[y] > trimLength)
                                    arr[y] = trimLength;

                            }
                        }

                        else
                        {
                            if (currentRow[y] != null && currentRow[y] != DBNull.Value)
                            {
                                string rs;
                                if (currentRow[y] is DateTime)
                                    rs = string.Format("{0:s}", currentRow[y]);
                                else
                                    rs = currentRow[y].ToString();
                                arr[y] = rs.Length > arr[y] ? rs.Length : arr[y];
                            }
                        }
                    }
                }

                for (int i = 0; i < arr.Count; i++)
                {
                    arr[i] = arr[i] + 0;
                }

                int index = 0;
                foreach (DataColumn item in dr1.Table.Columns)
                {
                    if (arr[index] < item.ColumnName.Length)
                        arr[index] = item.ColumnName.Length;

                    content.Append(item.ColumnName.PadRight(arr[index]));
                    content.Append(saparator);


                    index++;
                    if (index == intColumnCount)
                        content.AppendLine();
                }

                //add column data
                foreach (DataRow currentRow in table.Rows)
                {
                    for (int c = 0; c <= intColumnCount - 1; c++)
                    {
                        string rs;
                        if (currentRow[c] is DateTime)
                            rs = string.Format("{0:s}", currentRow[c]);
                        else
                            rs = currentRow[c]==DBNull.Value && showNULL ? "NULL" : currentRow[c].ToString();

                        content.Append(rs.PadRight(arr[c]).Substring(0, arr[c]));
                        content.Append(saparator);
                    }
                    content.AppendLine();
                }

            }

            return content.ToString();
        }
    }
}
