﻿using System;
using System.CodeDom;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.CSharp;

namespace SharedHelper
{
    public static class TypeHelper
    {
        public static string GetTypeAlias(string typeNameFull)
        {
            string typeName = typeNameFull;

            Type t = Type.GetType(typeNameFull);

            if (t != null)
            {
                using (var provider = new CSharpCodeProvider())
                {
                    var typeRef = new CodeTypeReference(t);
                    typeName = provider.GetTypeOutput(typeRef);
                }
            }

            return (typeName);
        }
        public static string GetTypeAlias(Type t)
        {
            string typeName = null;
            using (var provider = new CSharpCodeProvider())
            {
                var typeRef = new CodeTypeReference(t);
                typeName = provider.GetTypeOutput(typeRef);
            }

            return (typeName);
        }


        static public Type GetType(string type)
        {
            return Type.GetType(type);
        }

        static public bool IsEnumOrSystemType(this Type type)
        {
            return null != type && (type.IsEnum || type.Namespace == "System");
        }

        static public object GetChangeType(Type type, object value)
        {
            Type t = Nullable.GetUnderlyingType(type) ?? type;
            var r = t.IsEnum ? Enum.Parse(t, value.ToString()) : Convert.ChangeType(value, t);
            return r;
        }

        public static string GetEnumDescription(this Enum value)
        {
            DescriptionAttribute attribute = value.GetType()
                .GetField(value.ToString())
                .GetCustomAttributes(typeof(DescriptionAttribute), false)
                .SingleOrDefault() as DescriptionAttribute;
            return attribute == null ? value.ToString() : attribute.Description;
        }

        public static string GetEnumDescription<T>(T value)
        {
            if (!typeof(T).IsEnum) throw new ArgumentException("T must be an enumerated type");

            DescriptionAttribute attribute = value.GetType()
                .GetField(value.ToString())
                .GetCustomAttributes(typeof(DescriptionAttribute), false)
                .SingleOrDefault() as DescriptionAttribute;
            return attribute == null ? value.ToString() : attribute.Description;
        }

        public static T GetEnumValueFromDescription<T>(string description)
        {
            var type = typeof(T);
            if (!type.IsEnum)
                throw new ArgumentException();
            FieldInfo[] fields = type.GetFields();
            var field = fields
                            .SelectMany(f => f.GetCustomAttributes(
                                typeof(DescriptionAttribute), false), (
                                    f, a) => new { Field = f, Att = a })
                            .Where(a => ((DescriptionAttribute)a.Att)
                                .Description.Equals(description, StringComparison.OrdinalIgnoreCase)).SingleOrDefault();
            return field == null ? default(T) : (T)field.Field.GetRawConstantValue();
        }


        public static void Serialize<T>(T dataToSerialize, string filePath)
        {
            using (Stream stream = File.Open(filePath, FileMode.Create, FileAccess.ReadWrite))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                XmlTextWriter writer = new XmlTextWriter(stream, Encoding.Default);
                writer.Formatting = Formatting.Indented;
                serializer.Serialize(writer, dataToSerialize);
                writer.Close();
            }

        }

        //public static string Serialize<T>(T dataToSerialize)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    using (StringWriter stream = new StringWriter(sb))
        //    {                
        //        XmlSerializer serializer = new XmlSerializer(typeof(T));
        //        XmlTextWriter writer = new XmlTextWriter(stream);
        //        writer.Formatting = Formatting.Indented;
        //        serializer.Serialize(writer, dataToSerialize);
        //        writer.Close();
        //    }
        //    return sb.ToString();
        //}

        //public static T Deserialize<T>(string filePath)
        //{
        //    XmlSerializer serializer = new XmlSerializer(typeof(T));
        //    T serializedData;

        //    using (Stream stream = File.Open(filePath, FileMode.Open, FileAccess.Read))
        //    {
        //        serializedData = (T)serializer.Deserialize(stream);
        //    }
        //    return serializedData;

        //}

        //public static T DeserializeString<T>(string xml)
        //{
        //    XmlSerializer serializer = new XmlSerializer(typeof(T));
        //    T serializedData;


        //    using (Stream stream = GenerateStreamFromString(xml))
        //    {
        //        serializedData = (T)serializer.Deserialize(stream);
        //    }

        //    return serializedData;

        //}

        //public static Stream GenerateStreamFromString(string s)
        //{
        //    MemoryStream stream = new MemoryStream();
        //    StreamWriter writer = new StreamWriter(stream);
        //    writer.Write(s);
        //    writer.Flush();
        //    stream.Position = 0;
        //    return stream;
        //}
    }
}
