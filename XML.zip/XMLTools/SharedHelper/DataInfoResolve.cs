﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace SharedHelper
{
    public static class DataInfoResolve
    {
        private static ITypeCheck typeCheck = null;

        public static Type[] TypeCheckList = { typeof(short),
                                          //typeof(int), 
                                          //typeof(Int64), 
                                          //typeof(double), 
                                          typeof(string) };

        public static DataInfo Resolve(IEnumerable<string> values)
        {
            if (values.Any(x => x.AnyNonDecimalChar()))
                return new DataInfo(typeof(string), true, Slot(StringHelper.MaxLength(values)));

            return GetTypeCheckChain.Check(values);
        }

        static int[] slots = { 10, 20, 50, 64, 128, 256, 512, 1024, 8000 };
        private static int Slot(int len)
        {
            for (int i = 0; i < slots.Length; i++)
            {
                if (len <= slots[i])
                    return slots[i];
            }
            return len;
        }

        private static ITypeCheck GetTypeCheckChain
        {
            get
            {
                if (typeCheck == null)
                {

                    foreach (Type type in TypeCheckList)
                    {
                        TypeCheck currentTypeCheck = new TypeCheck(type);
                        if (typeCheck == null)
                        {
                            typeCheck = currentTypeCheck;
                        }
                        else
                        {
                            typeCheck.Next = currentTypeCheck;
                            currentTypeCheck.Previous = typeCheck;
                            typeCheck = currentTypeCheck;
                        }
                    }

                    while (typeCheck.Previous != null)
                    {
                        typeCheck = typeCheck.Previous;
                    }
                }
                return typeCheck;
            }
        }


        public interface ITypeCheck
        {
            DataInfo Check(IEnumerable<string> collection);
            ITypeCheck Previous { get; set; }
            ITypeCheck Next { get; set; }
        }



        private class TypeCheck : ITypeCheck
        {
            private Type checkType;
            private TypeConverter converter;
            private bool hasNullValue { get; set; }
            private bool hasNonMatchingType { get; set; }
            private bool hasMatchingType { get; set; }

            public TypeCheck(Type type)
            {
                converter = TypeDescriptor.GetConverter(type);
                this.checkType = type;

            }

            public DataInfo Check(IEnumerable<string> sourceValueCollection)
            {
                hasNullValue = false;
                hasMatchingType = false;
                hasNonMatchingType = false;
                foreach (var value in sourceValueCollection)
                {
                    if (string.IsNullOrWhiteSpace(value))
                    {
                        hasNullValue = true;
                    }
                    else if (converter.IsValid(value))
                    {
                        hasMatchingType = true;
                        continue;
                    }
                    else
                    {
                        hasNonMatchingType = true;
                        break;
                    }
                }

                if (hasNonMatchingType && this.Next != null)
                {
                    return this.Next.Check(sourceValueCollection);
                }
                else
                {
                    if (hasMatchingType)
                    {
                        return new DataInfo(this.checkType, hasNullValue, Slot(StringHelper.MaxLength(sourceValueCollection)));
                    }
                    else
                    {
                        return new DataInfo(typeof(string), hasNullValue, Slot(StringHelper.MaxLength(sourceValueCollection)));
                    }
                }
            }
            public ITypeCheck Next { get; set; }
            public ITypeCheck Previous { get; set; }
        }

        public class DataInfo
        {
            public DataInfo(Type type, bool Nullable, int length)
            {
                this.Type = type;
                this.Nullable = Nullable;
                this.MaxLength = length;
            }

            public Type Type { get; private set; }
            public bool Nullable { get; private set; }
            public int MaxLength { get; set; }
        }

    }
}
