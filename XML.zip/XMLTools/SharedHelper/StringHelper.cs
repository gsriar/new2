﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace SharedHelper
{
    public static class StringHelper
    {
        public static string ConcatFormat<T>(IEnumerable<T> source, string delimiter, string prefix, string suffix)
        {
            if (source == null)
                return null;
            StringBuilder sb = new StringBuilder();
            foreach (var x in source)
            {
                sb.AppendFormat("{0}{1}{2}{3}", prefix, x, suffix, delimiter);
            }
            sb.Length--;
            return sb.ToString();
        }


        public static int MaxLength(IEnumerable<string> source, int min = 20)
        {
            int l1 = min, l2 = 0;
            foreach (var x in source)
            {
                if (x != null)
                {
                    l2 = x.Length;
                }
                if (l2 > l1)
                {
                    l1 = l2;
                }
            }
            return l1;
        }

        public static string RemoveSpecialCharacters(this string str)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '.' || c == '_' || c == ' ')
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        public static string TrimSpecial(this string str)
        {
            if (string.IsNullOrWhiteSpace(str) || !(str[0] == '\r' || str[0] == '\n'))
            {
                return str;
            }

            return str.TrimStart(' ', '\r', '\n').TrimEnd(' ', '\r', '\n');

        }

        public static Stream StringToStream(this string s)
        {
            MemoryStream stream = new MemoryStream();
            StreamWriter writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }

        public static string ToTitleCase(this string s)
        {
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(s);
        }

        // Convert the string to Pascal case.
        public static string ToPascalCase(this string the_string)
        {
            // If there are 0 or 1 characters, just return the string.
            if (the_string == null) return the_string;
            if (the_string.Length < 2) return the_string.ToUpper();

            // Split the string into words.
            string[] words = the_string.Split(
                new char[] { },
                StringSplitOptions.RemoveEmptyEntries);

            // Combine the words.
            string result = "";
            foreach (string word in words)
            {
                result += word.Substring(0, 1).ToUpper() + word.Substring(1);
            }

            return result;
        }

        // Convert the string to Pascal case.
        public static string ToContinuousString(this string the_string)
        {
            // If there are 0 or 1 characters, just return the string.
            if (the_string == null) return the_string;
            //if (the_string.Length < 2) return the_string.ToUpper();

            // Split the string into words.
            string[] words = the_string.Split(
                new char[] { },
                StringSplitOptions.RemoveEmptyEntries);

            return string.Join("", words);

        }

        // Convert the string to Camel case.
        public static string ToCamelCase(this string the_string)
        {
            // If there are 0 or 1 characters, just return the string.
            if (the_string == null) return the_string;
            if (the_string.Length < 2) return the_string.ToUpper();

            // Split the string into words.
            string[] words = the_string.Split(
                new char[] { },
                StringSplitOptions.RemoveEmptyEntries);

            words[0] = words[0].Substring(0, 1).ToLower() + words[0].Substring(1);

            // Combine the words.
            string result = "";
            foreach (string word in words)
            {
                result += word;
            }

            return result;
        }

        // Capitalize the first character and add a space before
        // each capitalized letter (except the first character).
        public static string ToProperCase(this string the_string)
        {
            // If there are 0 or 1 characters, just return the string.
            if (the_string == null) return the_string;
            if (the_string.Length < 2) return the_string.ToUpper();

            // Start with the first character.
            string result = the_string.Substring(0, 1).ToUpper();

            // Add the remaining characters.
            for (int i = 1; i < the_string.Length; i++)
            {
                if (char.IsUpper(the_string[i])) result += " ";
                result += the_string[i];
            }

            return result;
        }

        public static bool AnyNonDecimalChar(this string str)
        {
            if (string.IsNullOrEmpty(str))
                return false;

            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') || c == '.')
                {
                    continue;
                }
                else
                {
                    return true;
                }
            }

            return false;
        }

        public static bool AnyNonNumericChar(this IEnumerable<string> str)
        {
            foreach (string s in str)
            {
                if (s.AnyNonDecimalChar())
                    return true;
            }
            return false;
        }

        public static string AnyNonNumericChar(this string str)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_' || c == ' ')
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        public static string ReplaceSQLSpecialCharactersWith(this string str, char replacement)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in str)
            {
                if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_' || c == ' ')
                {
                    sb.Append(c);
                }
                else
                {
                    sb.Append(replacement);
                }
            }
            return sb.ToString();
        }

        public static string CalculateMD5Hash(this string input)
        {
            // step 1, calculate MD5 hash from input
            MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);

            // step 2, convert byte array to hex string
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("X2"));
            }
            return sb.ToString();
        }
    }
}
