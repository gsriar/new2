using System;
using System.Collections.Generic;
using System.Text;
using TransactionUtility.Model;

namespace TransactionUtility.Model
{
	public enum DataFieldType
	{
		Numeric,
		Integer,
		Text,
		DateTime
	}
}
