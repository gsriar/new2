using System;
using System.Collections.Generic;
using System.Text;
using TransactionUtility.Model;

namespace TransactionUtility.TransactionTool
{
	public class LogWriter
	{
        public LogWriter() { }
        public void Write(string text)
        { 
        
        }
    }
}
